# CONFIGURACIÓN DE DISPARADORES NEORVRY
TRIGGERS = {
    "HORNEAR": "node reposteria_aida.js",
    "REPOSTERIA": "node reposteria_aida.js",
    "CURSO": "node reposteria_aida.js",
}
print("🛡️ INTERCEPTOR BLINDADO: Escuchando señales de Repostería...")
