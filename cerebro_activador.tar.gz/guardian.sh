#!/bin/bash
while true; do
  # Revisa si el Webhook de Python está vivo
  if ! pkill -0 -f "hotmart_webhook.py"; then
    echo "[Wed Apr 29 08:36:05 -04 2026] Reinstalando Webhook..." >> ~/logs/guardian.log
    python3 hotmart_webhook.py &
  fi
  
  # Revisa si el Túnel Bore está vivo
  if ! pkill -0 -f "bore"; then
    echo "[Wed Apr 29 08:36:05 -04 2026] Túnel caído. Reiniciando..." >> ~/logs/guardian.log
    # Aquí puedes poner tu comando de arranque del túnel
  fi
  sleep 60
done
