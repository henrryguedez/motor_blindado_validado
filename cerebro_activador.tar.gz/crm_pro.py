import os
import time
import sqlite3
import sys
from datetime import datetime

G, Y, C, R, W = "\033[92m", "\033[93m", "\033[96m", "\033[91m", "\033[0m"


class NeorvryQuantumCRM:
    def __init__(self):
        self.db_name = "nbuilder.db"
        self.auto_reparar_estructura()

    def auto_reparar_estructura(self):
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            cursor.execute("""CREATE TABLE IF NOT EXISTS leads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fecha TIMESTAMP, prefijo TEXT, nombre TEXT NOT NULL,
                producto TEXT, temperatura INTEGER DEFAULT 50,
                status TEXT DEFAULT 'PENDIENTE', metadata TEXT)""")
            conn.commit()
            conn.close()
        except Exception as e:
            pass

    def input_validado(self, prompt, validas=None):
        while True:
            valor = input(f"{G}{prompt}{W}").strip()
            if not valor:
                continue
            if validas and valor not in validas:
                print(f"{R}Selecciona una opción válida.{W}")
                continue
            return valor

    def registrar_lead_inteligente(self):
        os.system("clear")
        paises = {"1": "+58", "2": "+52", "3": "+34", "4": "+57", "5": "+1", "6": "+"}
        print(f"{Y}--- SELECCIÓN DE RADAR ---{W}")
        print(f"1.VEN 2.MEX 3.ESP 4.COL 5.USA 6.Otro")
        pais_op = self.input_validado("➤ Opción [1-6]: ", paises.keys())
        nombre = self.input_validado("➤ Nombre Prospecto: ")
        producto = input(f"{G}➤ Producto/Nicho: {W}").strip()

        temp = (
            90
            if any(x in producto.lower() for x in ["ia", "bot", "curso", "r22"])
            else 60
        )

        with sqlite3.connect(self.db_name) as conn:
            conn.cursor().execute(
                "INSERT INTO leads (fecha, prefijo, nombre, producto, temperatura, status) VALUES (?,?,?,?,?,?)",
                (
                    datetime.now().strftime("%Y-%m-%d %H:%M"),
                    paises[pais_op],
                    nombre,
                    producto,
                    temp,
                    "LISTO_PARA_BOT",
                ),
            )

        print(f"\n{G}✅ ¡LEAD REGISTRADO CON ÉXITO EN EL BÚNKER!{W}")
        input(f"{C}⏎ Presiona ENTER para continuar...{W}")

    def dashboard_inteligente(self):
        os.system("clear")
        print(f"{C}📊 DASHBOARD DE OPERACIONES R22{W}")
        print(f'{"-"*40}')
        with sqlite3.connect(self.db_name) as conn:
            rows = (
                conn.cursor()
                .execute(
                    "SELECT id, nombre, prefijo, temperatura, fecha FROM leads ORDER BY id DESC LIMIT 5"
                )
                .fetchall()
            )
            if not rows:
                print(f"{Y}Búnker vacío. Esperando inyecciones...{W}")
            for r in rows:
                print(f"{W}[{r[4]}] {r[2]} {r[1]} | 🔥 {r[3]}%")
        print(f'{"-"*40}')
        input(f"\n{C}⏎ Presiona ENTER para volver al menú...{W}")

    def ejecutar_menu(self):
        while True:
            os.system("clear")
            print(f"{G}💎 NEORVRY QUANTUM CRM R22 PRO{W}")
            print(f"1. ➕ Inyectar Lead\n2. 📊 Ver Dashboard\n3. 🚪 Salir")
            op = input(f"{G}➤ {W}")
            if op == "1":
                self.registrar_lead_inteligente()
            elif op == "2":
                self.dashboard_inteligente()
            elif op == "3":
                sys.exit(0)


if __name__ == "__main__":
    crm = NeorvryQuantumCRM()
    crm.ejecutar_menu()
