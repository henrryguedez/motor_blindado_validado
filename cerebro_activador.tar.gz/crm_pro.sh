#!/data/data/com.termux/files/usr/bin/bash
TURQUESA='\e[1;96m'
YELLOW='\e[1;93m'
NC='\e[0m'

clear
echo -e "${TURQUESA}📊 CRM PRO | SEGUIMIENTO DE VENTAS${NC}"
echo -e "------------------------------------------"
read -p "Nombre del Lead: " nombre
read -p "Interés (Ingles/Postre): " interes
echo "Estado: 1) Caliente  2) Tibio  3) Frío"
read -p "Opción: " estado_opt

case $estado_opt in
    1) est="CALIENTE 🔥" ;;
    2) est="TIBIO ⚡" ;;
    3) est="FRIO ❄️" ;;
esac

# Guardar en la base de datos local
echo "$(date '+%Y-%m-%d %H:%M') | $nombre | $interes | $est" >> crm_leads.txt
echo -e "\n${YELLOW}[OK] Registro actualizado en crm_leads.txt${NC}"
sleep 1.5
