import sqlite3, random, sys, os
from datetime import datetime, timedelta
from pathlib import Path

DB_PATH = Path.home() / ".neovry_vcv.db"
CONTENIDOS = {
    "VALOR": [
        "¡Tip! El 90% de los pasteles fallan por temperatura 🥚",
        "¡Secreto! Reposa la mezcla 5min antes del horno. 🍰",
    ],
    "CONFIANZA": [
        "Técnica envolvente = resultados gourmet. ¡Sin equipo caro!",
        "De 0 a 50 ventas/semana con utensilios de casa. 🚀",
    ],
    "VENTA": [
        "🚀 MANUAL +100 recetas: $47 -> $27 HOY. Link: https://tu-hotmart.com",
        "⏰ ÚLTIMA CHANCE $27. Link: https://tu-hotmart.com",
    ],
    "RECUERDO": [
        "¿Aún tienes dudas con el manual? 🍰 La oferta de $27 expira pronto.",
        "Vi que te interesó el manual. ¡Solo quedan 2 cupos con descuento! ⏰",
    ],
}


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""CREATE TABLE IF NOT EXISTS usuarios (
        id_usuario TEXT PRIMARY KEY, fase TEXT DEFAULT 'VALOR',
        score INTEGER DEFAULT 0, nombre TEXT, ultima_interaccion TEXT,
        ultimo_seguimiento TEXT, comprado BOOLEAN DEFAULT FALSE)""")
    conn.commit()
    conn.close()


def ejecutar_flujo(id_user, msg="", nombre="Amigo"):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    ahora = datetime.now().isoformat()
    c.execute(
        "INSERT OR IGNORE INTO usuarios (id_usuario, nombre, ultima_interaccion) VALUES (?, ?, ?)",
        (id_user, nombre, ahora),
    )
    c.execute(
        "SELECT fase, score, comprado FROM usuarios WHERE id_usuario=?", (id_user,)
    )
    fase, score, comprado = c.fetchone()
    intent = any(
        p in msg.lower() for p in ["precio", "cuanto", "costo", "comprar", "oferta"]
    )
    if intent and fase != "VENTA":
        res, fase, score = (
            "¡Directo al punto! " + random.choice(CONTENIDOS["VENTA"]),
            "VENTA",
            score + 8,
        )
    elif fase == "VALOR":
        res, fase, score = (
            f"¡Hola {nombre}! " + random.choice(CONTENIDOS["VALOR"]),
            "CONFIANZA",
            score + 1,
        )
    elif fase == "CONFIANZA":
        res, fase, score = random.choice(CONTENIDOS["CONFIANZA"]), "VENTA", score + 2
    else:
        res, fase, score = random.choice(CONTENIDOS["VENTA"]), "VENTA", score + 3
    c.execute(
        "UPDATE usuarios SET fase=?, score=?, ultima_interaccion=? WHERE id_usuario=?",
        (fase, score, ahora, id_user),
    )
    conn.commit()
    conn.close()
    return f"\n[NEOVRY BLACK OPS] -> {res}"


def modo_seguimiento():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    hace_24h = (datetime.now() - timedelta(hours=24)).isoformat()
    c.execute(
        "SELECT id_usuario, nombre FROM usuarios WHERE fase='VENTA' AND ultima_interaccion < ? AND ultimo_seguimiento IS NULL",
        (hace_24h,),
    )
    leads = c.fetchall()
    for lead_id, nombre in leads:
        msg = random.choice(CONTENIDOS["RECUERDO"])
        print(f"📢 SEGUIMIENTO PARA {nombre} ({lead_id}): {msg}")
        c.execute(
            "UPDATE usuarios SET ultimo_seguimiento=? WHERE id_usuario=?",
            (datetime.now().isoformat(), lead_id),
        )
    conn.commit()
    conn.close()


if __name__ == "__main__":
    if len(sys.argv) > 2:
        print(ejecutar_flujo(sys.argv[1], sys.argv[2]))
    elif "--cron" in sys.argv:
        modo_seguimiento()
