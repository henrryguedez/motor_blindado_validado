import sqlite3
import pandas as pd
from pathlib import Path

HOME = Path.home()
DB_PATH = HOME / ".neovry_vcv.db"


def glance_vcv():
    if not DB_PATH.exists():
        return print("No DB")
    conn = sqlite3.connect(DB_PATH)
    try:
        fases = pd.read_sql_query(
            "SELECT fase, COUNT(*) as n FROM usuarios GROUP BY fase", conn
        )
        print("V.C.V |", " | ".join([f"{r.fase}:{r.n}" for _, r in fases.iterrows()]))
    except:
        print("Iniciando sistema...")
    finally:
        conn.close()


if __name__ == "__main__":
    glance_vcv()
