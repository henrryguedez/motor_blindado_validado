#!/usr/bin/env python3
import requests, json


class NeovryV4:
    def matrix_response(self, mensaje):
        tag = mensaje.lower()

        # Tu API productos
        try:
            r = requests.get(f"http://localhost:8080/buscar?q={tag}", timeout=3)
            data = r.json()
            if data.get("encontrado"):
                return f"""🤖 *Neovry V4 Matrix*

{mensaje.upper()}

💎 *{data['nombre']}*
{data['descripcion']}

👉 {data['link']}"""
        except:
            pass

        # Respuesta genérica Matrix
        return f"""🤖 *Neovry V4 - Modo Matrix*

🔧 Embudo AIDA activado:
• A: ¡Repuestos para TODO carro!
• I: Diagnóstico IA gratis
• D: Video tutorial personalizado  
• A: Compra 1-click

¿Qué necesitas exactamente?"""


nv4 = NeovryV4()
print(nv4.matrix_response("repuestos bujías"))
