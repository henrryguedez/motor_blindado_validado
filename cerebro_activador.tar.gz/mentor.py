import os
import time

G = "\033[92m"
Y = "\033[93m"
W = "\033[0m"
B = "\033[94m"


def mentor():
    os.system("clear")
    print(f"{G}[SISTEMA]: Mentor Neorvry Activo...{W}")
    print(f"{Y}----------------------------------------{W}")
    print(f"{B}>> ANALIZANDO OBJECIONES FRECUENTES:{W}")
    print("1. 'Es muy caro' -> Vende el valor, no el precio.")
    print("2. 'No tengo tiempo' -> El tiempo se crea para lo que importa.")
    print("3. 'Lo voy a pensar' -> ¿Qué duda específica te detiene?")
    print(f"{Y}----------------------------------------{W}")
    print(f"\n{G}[!] Mentor listo para asesoría de cierre.{W}")
    input(f"\n{W}Presiona Enter para volver al Búnker...")


if __name__ == "__main__":
    mentor()
