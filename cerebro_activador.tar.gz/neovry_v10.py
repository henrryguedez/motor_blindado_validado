import os
import time
import sys
from PIL import Image, ImageDraw


class Colors:
    V = "\033[1;32m"
    A = "\033[1;34m"
    B = "\033[1;37m"
    C = "\033[1;36m"
    R = "\033[0m"


def print_logo():
    print(f"""{Colors.A}
    ███╗   ██╗███████╗ ██████╗ ██╗   ██╗██████╗ ██╗   ██╗
    ████╗  ██║██╔════╝██╔═══██╗██║   ██║██╔══██╗╚██╗ ██╔╝
    ██╔██╗ ██║█████╗  ██║   ██║██║   ██║██████╔╝ ╚████╔╝
    ██║╚██╗██║██╔══╝  ██║   ██║╚██╗ ██╔╝██╔══██╗  ╚██╔╝
    ██║ ╚████║███████╗╚██████╔╝ ╚████╔╝ ██║  ██║   ██║
    ╚═╝  ╚═══╝╚══════╝ ╚═════╝   ╚═══╝  ╚═╝  ╚═╝   ╚═╝
          --- BUILDER EMPIRE | VENEZUELA HUB ---{Colors.R}""")


def main():
    os.system("clear")
    print_logo()
    print(f"{Colors.B}[>] Iniciando Ecosistema v10.0 en Barquisimeto...{Colors.R}")
    time.sleep(1)

    # Simulación técnica de módulos
    for i in range(1, 21):
        print(f"{Colors.A}[OK]{Colors.R} Activando Módulo {i:02d}...", end="\r")
        time.sleep(0.05)
    print(f"\n{Colors.V}¡SISTEMA VALIDADO Y BLINDADO!{Colors.R}\n")

    # Render de video
    if not os.path.exists("tmp_f"):
        os.makedirs("tmp_f")
    print(f"{Colors.C}[>] Generando contenido visual...{Colors.R}")

    w, h = 720, 1280
    for i in range(60):
        img = Image.new("RGB", (w, h), "black")
        draw = ImageDraw.Draw(img)
        sy = (i * 45) % h
        draw.line([(0, sy), (w, sy)], fill=(0, 100, 0), width=15)
        draw.text((80, 500), "NEOVRY BUILDER PRO", fill=(0, 255, 255))
        draw.text((80, 550), "INFRAESTRUCTURA PROPIA", fill=(255, 255, 255))
        bar = (i / 60) * 560
        draw.rectangle([80, 650, 80 + bar, 680], fill=(0, 255, 0))
        img.save(f"tmp_f/f_{i:03d}.png")

    print(f"{Colors.V}[>] Finalizando renderizado con FFMPEG...{Colors.R}")
    os.system(
        "ffmpeg -y -framerate 10 -i tmp_f/f_%03d.png -c:v libx264 -pix_fmt yuv420p promo_neovry.mp4 -loglevel quiet"
    )
    os.system("rm -rf tmp_f")

    print(f"\n{Colors.V}✅ ¡BELLEZA! Video listo: promo_neovry.mp4{Colors.R}")
    print(f"{Colors.C}Para mover a tu galería usa:{Colors.R}")
    print(f"{Colors.B}cp promo_neovry.mp4 /sdcard/Download/{Colors.R}")


if __name__ == "__main__":
    main()
