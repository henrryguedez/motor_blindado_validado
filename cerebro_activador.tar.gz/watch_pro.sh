#!/bin/bash
echo "🔍 MONITOR PRO - Detecta ventas ÚNICAS"
declare -i last_lines=0

while true; do
  lines=$(wc -l < ventas.txt)
  if [ $lines -gt $last_lines ]; then
    new_line=$(tail -n +$((last_lines+1)) ventas.txt | head -1)
    echo "💰 VENTA NUEVA: $new_line"
    
    # Buscar producto directo
    producto=$(python3 neovry_pro.py "$(echo $new_line | cut -d'|' -f4)" 2>/dev/null | jq -r '.nombre // empty')
    echo "   📦 Producto: $producto"
    
    last_lines=$lines
  fi
  sleep 3
done
