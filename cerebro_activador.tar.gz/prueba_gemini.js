const { GoogleGenerativeAI } = require("@google/generative-ai");

const genAI = new GoogleGenerativeAI("AIzaSyAfVpfkXO2OMoEVi5IOko4GxD1iLlvdifo");

async function inspeccionar() {
  try {
    console.log("--- INICIANDO INSPECCIÓN DE CAPACIDADES ---");
    // Esto lista los modelos disponibles para TU llave
    const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models?key=AIzaSyAfVpfkXO2OMoEVi5IOko4GxD1iLlvdifo");
    const data = await response.json();
    
    if (data.models) {
      console.log("Modelos encontrados en tu cuenta:");
      data.models.forEach(m => console.log("- " + m.name));
    } else {
      console.log("No se devolvieron modelos. Respuesta de Google:", JSON.stringify(data));
    }
  } catch (error) {
    console.error("Error en la inspección física:", error.message);
  }
}

inspeccionar();
