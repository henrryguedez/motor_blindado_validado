import subprocess


def consultar_ia(msg):
    comando = ["ollama", "run", "smollm:135m", f"Short tip: {msg}"]
    try:
        res = subprocess.run(comando, capture_output=True, text=True, timeout=10)
        return res.stdout.strip()
    except:
        return "Ollama dormido"


if __name__ == "__main__":
    print("--- NEORVRY CORE (SMOL) ---")
    print(f'IA: {consultar_ia("reposteria")} ')
