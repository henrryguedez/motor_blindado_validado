import requests

def enviar_mensaje(texto):
    token = "8658877853:AAE9MDxujiGgwdvYwNY0BFVmmYNyiPF2U20"
    chat_id = "6951875143" 
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {"chat_id": chat_id, "text": texto, "parse_mode": "Markdown"}
    
    r = requests.post(url, data=payload)
    if r.status_code == 200:
        print("🚀 ¡Mensaje enviado con éxito a Henrry!")
    else:
        print(f"❌ Error: {r.text}")

enviar_mensaje("¡Hola Henrry! 🚀\n\nTu bot **Mi Bot de control** ya está vinculado correctamente a tu sistema Neovry.")

