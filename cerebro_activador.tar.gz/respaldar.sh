#!/bin/bash
# Ruta de origen y destino
ORIGEN="neovry_users.json"
DESTINO="storage/downloads/neovry_backups/respaldo_$(date +%Y%m%d_%H%M%S).json"

# Copiar el archivo
cp $ORIGEN $DESTINO
echo "✅ Respaldo creado en: $DESTINO"
	
