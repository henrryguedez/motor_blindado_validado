module.exports = {
    MAX_MENSAJES: 100
};
