import os

G, Y, C, W = "\033[92m", "\033[93m", "\033[96m", "\033[0m"


def ver_victorias():
    os.system("clear")
    print(f"{G}╔══════════════════════════════════════╗")
    print(f"║     🏆 BITÁCORA DE VICTORIAS R22     ║")
    print(f"╚══════════════════════════════════════╝{W}")

    total = 0.0
    if os.path.exists("victorias.txt"):
        print(f"{C}FECHA      | CLIENTE        | MONTO{W}")
        print("-" * 40)
        with open("victorias.txt", "r") as f:
            for line in f:
                fec, nom, mon = line.strip().split("|")
                print(f"{W}{fec} | {nom[:12]:<12} | ${mon}{W}")
                total += float(mon)
        print("-" * 40)
        print(f"{G}TOTAL ACUMULADO: ${total} USD{W}")
        print(f"{Y}FALTANTE PARA $1M: ${1000000 - total} USD{W}")
    else:
        print(f"{Y}[!] Aún no hay victorias registradas.{W}")

    input(f"\n{G}Presiona Enter para volver...{W}")


if __name__ == "__main__":
    ver_victorias()
