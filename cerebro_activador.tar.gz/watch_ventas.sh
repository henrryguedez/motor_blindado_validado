#!/bin/bash
echo "🔍 Monitoreando ventas.txt..."
while true; do
  if [ -s ventas.txt ]; then
    echo "💰 NUEVA VENTA: $(tail -1 ventas.txt)"
    curl -s "localhost:8080/buscar?q=$(tail -1 ventas.txt | cut -d'|' -f4)" | jq .
  fi
  sleep 5
done
