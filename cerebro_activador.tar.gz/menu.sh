#!/bin/bash
# 🚀 NEORVRY BUILDER v4.5 - ALERTA DE RESULTADOS
# Optimizado para Cierre Orgánico (Método Desafío 400)

TURQUESA='\e[1;96m'; BLANCO='\e[1;97m'; YELLOW='\e[1;93m'
GREEN='\e[1;92m'; RED='\e[1;91m'; PURPLE='\e[1;95m'
CYAN='\e[0;36m'; BOLD='\e[1m'; NC='\e[0m'

DB_PATH="$HOME/.neovry_vcv.db"
VCPY="$HOME/vcv_elite.py"

# Función que te avisa si hay ventas calientes
check_ventas() {
    # Busca leads con score alto que ya recibieron el link de venta
    POTENCIAL=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM usuarios WHERE score >= 30 AND fase='VENTA';")
    if [ "$POTENCIAL" -gt 0 ]; then
        echo -e "${RED}⚠️  ¡AVISO DE POSIBLE VENTA!${NC}"
        echo -e "${YELLOW}Tienes $POTENCIAL lead(s) que ya revisaron la oferta de Repostería.${NC}"
        echo -e "${GREEN}💰 Revisa tu App de Hotmart ahora mismo.${NC}"
        echo -e "${PURPLE}──────────────────────────────────────────────────${NC}"
    fi
}

print_banner() {
    clear
    echo -e "${TURQUESA}███╗  ██╗███████╗ ██████╗ ██╗   ██╗██████╗ ██╗   ██╗"
    echo -e "████╗ ██║██╔════╝██╔═══██╗██║   ██║██╔══██╗╚██╗ ██╔╝"
    echo -e "██╔██╗██║█████╗  ██║   ██║██║   ██║██████╔╝ ╚████╔╝ "
    echo -e "██║╚████║██╔══╝  ██║   ██║╚██╗ ██╔╝██╔══██╗  ╚██╔╝  "
    echo -e "██║ ╚███║███████╗╚██████╔╝ ╚████╔╝ ██║  ██║   ██║   "
    echo -e "╚═╝  ╚══╝╚══════╝ ╚═════╝   ╚═══╝  ╚═╝  ╚═╝   ╚═╝${NC}"
    echo -e "      ${BLANCO}BUILDER EMPIRE | VENEZUELA HUB 🇻🇪${NC}"
}

while true; do
    print_banner
    check_ventas # <--- Aquí el sistema te grita si hay dinero cerca
    echo -e "📊 MÉTRICAS: $(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM usuarios;") Leads en Base de Datos"
    echo -e "           ⚡ ${YELLOW}MODO: AFILIADO PRO${NC} ⚡"
    echo -e "  ${TURQUESA}1) CRM (Leads Fuego)   ${GREEN}2) Artillería V.C.V${NC}"
    echo -e "  ${TURQUESA}3) Seguir Manual       ${GREEN}4) Ver Bitácora${NC}"
    echo -e "  ${TURQUESA}5) Salir${NC}"
    echo -e "${PURPLE}──────────────────────────────────────────────────${NC}"
    echo -ne "${BOLD}➤ Orden Maestro: ${NC}"
    read orden

    case $orden in
        1) sqlite3 -header -column "$DB_PATH" "SELECT nombre, score, fase FROM usuarios ORDER BY score DESC LIMIT 10;"; read -p "Enter..." ;;
        2) python3 "$VCPY" --test "all" "OFERTA_FLASH"; read -p "Enter..." ;;
        3) read -p "ID: " id; read -p "Msg: " m; python3 "$VCPY" --test "$id" "$m"; read -p "Enter..." ;;
        4) tail -n 10 "$HOME/neovry_logs"; read -p "Enter..." ;;
        5) exit 0 ;;
        *) continue ;;
    esac
done

