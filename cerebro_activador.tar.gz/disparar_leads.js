const { 
    makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    makeCacheableSignalKeyStore,
    Browse
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const qrcode = require('qrcode-terminal');

async function quantumEngine() {
    const { state, saveCreds } = await useMultiFileAuthState('./auth_info_baileys');
    
    const sock = makeWASocket({
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
        },
        printQRInTerminal: false,
        logger: pino({ level: 'silent' }),
        // Cambiamos el UserAgent para evitar el rechazo 405
        browser: ["Ubuntu", "Chrome", "20.0.04"]
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
            console.clear();
            console.log('🚀 QUANTUM CRM: VINCULACIÓN REQUERIDA');
            qrcode.generate(qr, { small: true });
        }

        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            
            if (code === 405 || code === DisconnectReason.loggedOut) {
                console.log('⚠️ Conflicto 405 detectado. Reajustando credenciales...');
                // No borramos todo, pero forzamos reinicio limpio
                setTimeout(() => quantumEngine(), 2000);
            } else {
                console.log('🔴 Reintentando conexión... Código:', code);
                setTimeout(() => quantumEngine(), 3000);
            }
        } else if (connection === 'open') {
            console.clear();
            console.log('✅ QUANTUM CRM: MOTOR EN LÍNEA Y VINCULADO');
        }
    });
}

quantumEngine();
