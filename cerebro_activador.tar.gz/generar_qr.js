import QRCode from 'qrcode';

// Cambiamos a la URL de Repostería (o tu landing específica)
const url = 'https://sistema-unificado.vercel.app/reposteria'; 
const nombreArchivo = 'qr_reposteria.png';

try {
    await QRCode.toFile(nombreArchivo, url, {
        color: {
            dark: '#4B2C20', // Un color café oscuro para que combine con el tema dulce
            light: '#FFFFFF'
        }
    });
    console.log(`✅ QR generado: ${nombreArchivo}`);
} catch (err) {
    console.error('❌ Error:', err);
}

