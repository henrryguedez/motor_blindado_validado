from vcv_logic import ejecutar_flujo_vcv

# Simulamos que llega un mensaje de un cliente nuevo
print("--- Iniciando Prueba de Sistema V.C.V ---")
ejecutar_flujo_vcv("584126665544@s.whatsapp.net", "Me interesa la repostería", "Juan")
print("--- Prueba Finalizada con Éxito ---")
