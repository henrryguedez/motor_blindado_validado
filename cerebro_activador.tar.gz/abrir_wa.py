import os
import time
import urllib.parse

G, B, Y, C, M, W = "\033[92m", "\033[94m", "\033[93m", "\033[96m", "\033[95m", "\033[0m"


def ia_redactor(perfil):
    print(f"\n{M}[IA]: Analizando psicología del prospecto...{W}")
    time.sleep(1)

    # Base de datos de copys de alta conversión
    copys = {
        "1": "Hola Henrry, soy profesional y mi mayor problema es el tiempo. Quiero el método de Inglés en 30 días para escalar mi carrera. ¿Cómo accedo?",
        "2": "Hola, estoy cansado de métodos tradicionales. Vi que Neorvry usa tecnología avanzada. Quiero inscribirme ya al programa de inglés.",
        "3": "Hola Henrry, soy emprendedor. Me interesa tu sistema de marketing de afiliados para generar ingresos en dólares. Dame los detalles.",
        "4": "Hola, vi tu sistema de acción digital. Me interesa la tecnología Neorvry. ¿Cómo puedo ser parte del equipo de promotores?",
    }
    return copys.get(perfil, "Hola, me interesa tu propuesta.")


def generar_link():
    os.system("clear")
    print(f"{M}╔══════════════════════════════════════╗")
    print(f"║     🧠 NEORVRY AI-LINK ENGINE        ║")
    print(f"║       NÚCLEO DE REDACCIÓN AUTO       ║")
    print(f"╚══════════════════════════════════════╝{W}")

    numero = "584240000000"

    print(f"{C}Seleccione el Perfil del Cliente:{W}")
    print("1. Ejecutivo/Profesional (Urgencia)")
    print("2. Estudiante Escéptico (Busca Innovación)")
    print("3. Inversionista/Emprendedor (Busca $)")
    print("4. Tecnólogo (Interesado en el Sistema)")

    perfil = input(f"\n{G}➤ Perfil: {W}")

    mensaje = ia_redactor(perfil)
    mensaje_url = urllib.parse.quote(mensaje)
    link_final = f"https://wa.me/{numero}?text={mensaje_url}"

    print(f"\n{G}[✔] COPY ESTRATÉGICO GENERADO:{W}")
    print(f'{Y}"{mensaje}"{W}')
    print(f"\n{B}Link: {link_final}{W}")

    lanzar = input(f"\n{C}¿Lanzar ataque a WhatsApp? (s/n): {W}").lower()
    if lanzar == "s":
        os.system(f"termux-open-url '{link_final}'")

    input(f"\n{W}Presiona Enter para volver...")


if __name__ == "__main__":
    generar_link()
