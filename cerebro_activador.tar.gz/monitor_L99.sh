#!/bin/bash
while true; do
    if ! pgrep -f "neovry_v9.py" > /dev/null; then
        echo "[L99-CRITICAL] IA caída. Reiniciando Motor..."
        python3 neovry_v9.py > ./logs/ia.log 2>&1 &
    fi
    sleep 10
done
