import datetime

def generar_reporte():
    print("\n--- 🚀 GENERADOR DE REPORTE - ALIANZA INDETENIBLE ---")
    
    nombre_afiliado = "Henrry José Guedez Castillo"
    # El correo de registro que usas en Hotmart/Desafío 400
    correo_afiliado = "tu_correo@ejemplo.com" 
    
    print("\n--- DATOS DEL COMPRADOR ---")
    try:
        cliente = input("Nombre del comprador: ")
        correo_cliente = input("Correo del comprador: ")
        producto = input("Nombre del producto vendido: ")
        fecha_str = input("Fecha de compra (DD/MM/YYYY): ")
        
        # Procesar fecha
        fecha_venta = datetime.datetime.strptime(fecha_str, "%d/%m/%Y")
        fecha_cobro = fecha_venta + datetime.timedelta(days=17)
        
        mensaje = f"""
✅ *SOLICITUD DE COMISIÓN - ALIANZA INDETENIBLE*

*DATOS DEL AFILIADO:*
• Nombre: {nombre_afiliado}
• Correo: {correo_afiliado}

*DATOS DE LA VENTA:*
• Producto: {producto}
• Fecha de Compra: {fecha_str}
• Comprador: {cliente}
• Correo Comprador: {correo_cliente}

*RECORDATORIO INTERNO:*
📅 Cobro disponible a partir del: {fecha_cobro.strftime('%d/%m/%Y')}
--------------------------------------------------
"""
        print(mensaje)
        
        with open("registro_comisiones.txt", "a") as f:
            f.write(mensaje)
        print("📌 Reporte guardado en registro_comisiones.txt")
        
    except ValueError:
        print("❌ Error: Usa el formato de fecha DD/MM/YYYY (ejemplo: 08/05/2026)")

if __name__ == "__main__":
    generar_reporte()
