import os
import time
import requests
from datetime import datetime

# Configuración
ARCHIVO = "Sistema_Ventas_Neovry_V1.xlsx"
URL_VERCEL = (
    "https://neovry-system-2026.vercel.app/api/notificar"  # Tu endpoint en Vercel
)


def monitorear():
    print("👀 Vigilante NEORVRY activado... Esperando ventas.")
    # Obtener la fecha de modificación actual
    ultima_mod = os.path.getmtime(ARCHIVO)

    while True:
        try:
            time.sleep(5)  # Revisa cada 5 segundos
            mod_actual = os.path.getmtime(ARCHIVO)

            if mod_actual != ultima_mod:
                print("🚀 ¡Cambio detectado en el Excel! Avisando a Vercel...")
                payload = {
                    "mensaje": "¡Nueva venta registrada en el sistema NEORVRY!",
                    "hora": datetime.now().strftime("%H:%M:%S"),
                }
                # Enviamos la señal a tu nube
                requests.post(URL_VERCEL, json=payload)
                ultima_mod = mod_actual
        except Exception as e:
            print(f"Error: {e}")
            time.sleep(10)


if __name__ == "__main__":
    monitorear()
