import requests

# Definimos el token directamente para la prueba
TOKEN = "8658877853:AAE9MDxujiGgwdvYwNY0BFVmmYNyiPF2U20"
url = f"https://api.telegram.org/bot{TOKEN}/getMe"

try:
    response = requests.get(url)
    if response.status_code == 200:
        print("✅ Conexión exitosa:")
        print(response.json())
    else:
        print(f"❌ Error {response.status_code}: {response.text}")
except Exception as e:
    print(f"💥 Ocurrió un error: {e}")

