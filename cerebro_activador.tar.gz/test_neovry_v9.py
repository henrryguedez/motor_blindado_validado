# Test Matrix V9 con nuevo JSON
import json

data = json.load(open("productos.json"))
print("PRODUCTOS CARGADOS:", len(data))
print("TOP PRIORIDAD:", max(data, key=lambda k: data[k]["prioridad"]))
