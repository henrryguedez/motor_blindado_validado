#!/bin/bash
# 🚀 Neorvry Stripe PRO - Todo automático

echo "🚀 Iniciando Stripe Config..."

# 1. Verifica deps
pip show stripe flask || pip install stripe flask

# 2. Crea stripe_config.py CORRECTO (tu versión mejorada)
cat > stripe_config.py << 'EOF'
import os
import stripe
from flask import Flask, request, jsonify

# TU KEY
with open('.stripe_key.txt', 'r') as f:
    stripe.api_key = f.read().strip()

app = Flask(__name__)

@app.route('/create-payment', methods=['POST'])
def create_payment():
    data = request.json
    cliente = data['cliente']
    monto = data['monto']
    # LLAMA TU CRM REAL
    os.system(f"python3 crm_pro.py --cliente '{cliente}' --monto {monto}")
    
    session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
            'price_data': {
                'currency': 'usd',
                'product_data': {'name': f'Neorvry - {cliente}'},
                'unit_amount': int(monto * 100),
            },
            'quantity': 1,
        }],
        mode='payment',
        success_url='http://localhost:5000/success?session_id={CHECKOUT_SESSION_ID}',
        cancel_url='http://localhost:5000/cancel',
    )
    return jsonify({'url': session.url})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=False)
EOF

# 3. Mata viejos procesos
pkill -f stripe_config.py

# 4. Inicia Stripe
nohup python3 stripe_config.py > stripe.log 2>&1 &
STRIPE_PID=$!
echo $STRIPE_PID > stripe.pid
sleep 5

echo "✅ Stripe corriendo en puerto 5001"
tail -5 stripe.log

# 5. PRUEBA VENTA REAL $35
echo "🧪 Creando pago Katherin..."
curl -X POST http://localhost:5001/create-payment \
  -H "Content-Type: application/json" \
  -d '{"cliente":"Katherin Guedez","monto":35}' 

echo "💰 Revisa:"
echo "tail -f stripe.log"
echo "cat ventas.txt  # Tu tracker"
echo "python3 crm_pro.py  # Ver registro"
a
