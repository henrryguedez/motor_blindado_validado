import os

# Colores Neón
G = "\033[1;32m"  # Verde
B = "\033[1;34m"  # Azul
R = "\033[1;31m"  # Rojo
Y = "\033[1;33m"  # Amarillo
C = "\033[1;36m"  # Cian
W = "\033[0m"  # Blanco


def show_bunker():
    os.system("clear")
    print(f"{B}╔══════════════════════════════════════════════════════════╗{W}")
    print(f"{B}║{G}    ⚡ NEORVRY BUILDER EMPIRE | NÚCLEO ACTIVO ⚡         {B}║{W}")
    print(f"{B}╠══════════════════════════════════════════════════════════╣{W}")
    print(f"{B}║{C}  [✔] TÚNEL: CONECTADO (Cloudflare)                       {B}║{W}")
    print(f"{B}║{C}  [✔] WEBHOOK: ESCUCHANDO PUERTO 5000                     {B}║{W}")
    print(f"{B}║{C}  [✔] BASE DE DATOS: nbuilder.db OPTIMIZADA               {B}║{W}")
    print(f"{B}╠══════════════════════════════════════════════════════════╣{W}")
    print(f"{B}║{Y}  >> RADAR DE VENTAS:                                     {B}║{W}")
    print(f"{B}║{W}     Cliente: Henrry Cliente                              {B}║{W}")
    print(f"{B}║{G}     Estado: ¡PAGO PROCESADO EXITOSAMENTE! 💰             {B}║{W}")
    print(f"{B}╚══════════════════════════════════════════════════════════╝{W}")
    print(f"\n{Y}   [ SISTEMA EN ESPERA DE NUEVOS CLIENTES... ]{W}\n")


if __name__ == "__main__":
    show_bunker()
