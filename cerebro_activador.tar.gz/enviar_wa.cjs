const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, DisconnectReason } = require("@whiskeysockets/baileys");
const pino = require("pino");

async function conectarWA() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({browser: ["Ubuntu", "Chrome", "20.0.04"],
        auth: state,
        version,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        browser: ["Ubuntu", "Chrome", "20.0.04"]
    });

    if (!sock.authState.creds.registered) {
        console.log("\n\033[1;33m[⏳] GENERANDO CÓDIGO DE PODER...\033[0m");
        setTimeout(async () => {
            try {
                const code = await sock.requestPairingCode("584167443305");
                console.log("\n\033[1;32m╔══════════════════════════════════════╗\033[0m");
                console.log("  CÓDIGO: \033[1;33m" + code + "\033[0m");
                console.log("\033[1;32m╚══════════════════════════════════════╝\033[0m");
            } catch (e) { process.exit(1); }
        }, 5000);
    }

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'open') {
            console.log("\n\033[1;32m[✔] ¡BÚNKER CONECTADO Y BLINDADO!\033[0m");
        }
        if (connection === 'close') {
            const error = lastDisconnect?.error?.output?.statusCode;
            if (error !== DisconnectReason.loggedOut) {
                process.exit(1); // El Bash lo reiniciará
            }
        }
    });
}
conectarWA();
