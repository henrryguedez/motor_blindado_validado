import pandas as pd

# Datos iniciales de ejemplo
data = {
    "Fecha": ["2026-05-01", "2026-05-02"],
    "Producto": ["Curso Inglés", "Pastelería Pro"],
    "Categoría": ["Educación", "Gastronomía"],
    "Precio Producto ($)": [150.00, 80.00],
    "Comisión Recibida ($)": [75.00, 40.00],
    "Plataforma": ["Hotmart", "Hotmart"],
    "ID Transacción": ["HT-98765", "HT-12345"],
}

df = pd.DataFrame(data)

# Crear el Excel directamente aquí
nombre_archivo = "Sistema_Ventas_Neovry_V1.xlsx"
df.to_excel(nombre_archivo, sheet_name="Registro de Ventas", index=False)

print(f"✅ Archivo {nombre_archivo} creado con éxito en tu carpeta actual.")
