#!/bin/bash
cd neovry_productos && ./run_pro.sh && cd ..
