#!/bin/bash
G='\033[0;32m'
B='\033[0;34m'
NC='\033[0m'

while true; do
    clear
    echo -e "${B}[SISTEMA GENERADOR DE INGRESOS ACTIVADO]${NC}"
    echo "------------------------------------------"
    echo -e "${G}ESTRATEGIA 2026: VALIDADA Y BLINDADA${NC}"
    echo "------------------------------------------"
    echo -e "${B}NEORVRY BUILDER PRO ⚡${NC}"
    echo -e "1) ${G}CRM Pro${NC}    2) ${G}Copy Venta (Mentor)${NC}"
    echo -e "3) ${G}Lead Auto${NC}  4) ${G}Ver Bitácora${NC}"
    echo -e "5) ${G}Salir al Terminal${NC}"
    echo "=========================================="
    echo -n "➤ "
    read opcion

    case $opcion in
        1) python crm_pro.py ; echo -e "\nPresiona Enter para volver..."; read ;;
        2) python mentor.py ; echo -e "\nPresiona Enter para volver..."; read ;;
        3) python interceptor.py ; echo -e "\nPresiona Enter para volver..."; read ;;
        4) python bitacora.py ; echo -e "\nPresiona Enter para volver..."; read ;;
        5) echo "Saliendo al terminal..."; break ;;
        *) echo "Opción no válida..." ; sleep 1 ;;
    esac
done
