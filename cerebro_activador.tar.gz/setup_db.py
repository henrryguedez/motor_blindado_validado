import os
import sqlite3


def inicializar_bunker_datos(db_name="app_session.db"):
    directorio = os.path.expanduser("~/session_db")
    if not os.path.exists(directorio):
        os.makedirs(directorio)
        print(f"✅ Directorio creado: {directorio}")

    ruta_db = os.path.join(directorio, db_name)
    conexion = sqlite3.connect(ruta_db)
    cursor = conexion.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sesiones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id TEXT UNIQUE,
            estado TEXT,
            fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS leads_captura (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT,
            telefono TEXT UNIQUE,
            producto TEXT,
            estado_seguimiento TEXT DEFAULT 'Pendiente',
            fecha_ingreso TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conexion.commit()
    print(f"🚀 Sistema de Datos Inicializado en: {ruta_db}")
    return conexion


if __name__ == "__main__":
    db = inicializar_bunker_datos()
    db.close()
