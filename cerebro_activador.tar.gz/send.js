const { default: makeWASocket, useMultiFileAuthState, Browsers, DisconnectReason, fetchLatestBaileysVersion } = require("@whiskeysockets/baileys");
const pino = require("pino");
const path = require('path');
const fs = require('fs');

const sessionDir = path.join(process.env.HOME, 'session_db');
if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir, { recursive: true });
const dbPath = path.join(sessionDir, 'leads.json');

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState(path.join(sessionDir, 'auth_info_baileys'));
    
    // Obtenemos la versión más reciente para evitar el 405
    const { version, isLatest } = await fetchLatestBaileysVersion();
    console.log(`\x1b[1;36m[ SISTEMA ] Usando versión v${version.join('.')}\x1b[0m`);

    const sock = makeWASocket({
        auth: state,
        version, // Inyectamos la versión oficial
        logger: pino({ level: "silent" }),
        browser: Browsers.macOS("Chrome"),
        syncFullHistory: false,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 15000
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, pairingCode } = update;
        
        if (connection === 'close') {
            const statusCode = lastDisconnect?.error?.output?.statusCode;
            console.log(`\x1b[1;31m[ RE-INTENTO ] Status: ${statusCode}\x1b[0m`);
            // Si es error de red, esperamos antes de reintentar
            setTimeout(startBot, 5000);
        } else if (connection === 'open') {
            console.log("\n\x1b[1;32m✅ BÚNKER ONLINE: ACCESO CONCEDIDO\x1b[0m");
        }

        if (pairingCode && !sock.authState.creds.registered) {
            console.log("\n\x1b[1;92m======================================");
            console.log("CÓDIGO DE VINCULACIÓN: " + pairingCode);
            console.log("======================================\x1b[0m");
        }
    });

    sock.ev.on("messages.upsert", async (m) => {
        const msg = m.messages[0];
        if (!msg.key.fromMe && m.type === "notify") {
            const num = msg.key.remoteJid.split('@')[0];
            let leads = fs.existsSync(dbPath) ? JSON.parse(fs.readFileSync(dbPath)) : [];
            if (!leads.find(l => l.telefono === num)) {
                leads.push({ nombre: msg.pushName || "Cliente", telefono: num, fecha: new Date().toLocaleString() });
                fs.writeFileSync(dbPath, JSON.stringify(leads, null, 2));
                console.log(`\x1b[1;32m[ LEAD ] ${num}\x1b[0m`);
            }
        }
    });
}
startBot();
