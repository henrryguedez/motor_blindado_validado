const { GoogleGenerativeAI } = require("@google/generative-ai");
require('dotenv').config();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-flash-latest" });

async function generarCopy() {
  const prompt = "Actúa como un experto en copywriting de respuesta directa. Crea un anuncio para TikTok de 30 segundos para el curso 'Repostería y Decoración'. Usa el gancho de: 'Cómo emprender desde casa sin ser experta'. Incluye: Gancho potente, Beneficio real (más de 40 lecciones), Escasez (oferta de 45 USD) y un Llamado a la acción claro al enlace de Hotmart.";
  
  try {
    const result = await model.generateContent(prompt);
    console.log("\x1b[32m%s\x1b[0m", "--- ESTRATEGIA DE VENTA: REPOSTERÍA Y DECORACIÓN ---");
    console.log(result.response.text());
  } catch (e) {
    console.log("Error:", e.message);
  }
}
generarCopy();
