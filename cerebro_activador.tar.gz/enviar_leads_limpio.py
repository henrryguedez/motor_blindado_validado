import os
import time

filename = "leads_recientes.txt"
if os.path.exists(filename):
    with open(filename, "r") as f:
        leads = [l.strip() for l in f.readlines() if l.strip()][:10]

    print(f"🚀 Procesando {len(leads)} leads...")
    for numero in leads:
        print(f"📦 Enviando a: {numero}")
        # Usamos tu motor de envío por comando de sistema
        os.system(f"node enviar_simple.js {numero} 'Hola, vi tu interés en el curso.'")
        time.sleep(2)  # Pausa para evitar baneo
else:
    print("❌ No hay archivo de leads.")
