import sqlite3
import os


def reporte_pulpo():
    db_path = os.path.expanduser("~/.neovry_vcv.db")
    if not os.path.exists(db_path):
        print("❌ Error: No se encuentra la base de datos.")
        return

    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    print("\n🐙 [ ECOSISTEMA NEOVRY V10.0 - STATUS ] 🐙")
    print("-" * 45)

    # Resumen General
    res = cur.execute("SELECT COUNT(*), SUM(score) FROM usuarios").fetchone()
    print(f"📊 LEADS TOTALES: {res[0]}  |  🔥 TEMPERATURA GLOBAL: {res[1] or 0} pts")

    # Leads con mayor Score (Los que tienen el dinero en la mano)
    print("\n🔥 TOP PROSPECTOS (Prioridad de Cierre):")
    calientes = cur.execute(
        "SELECT id_usuario, score, fase FROM usuarios WHERE score > 0 ORDER BY score DESC LIMIT 5"
    ).fetchall()

    if calientes:
        for user in calientes:
            print(f" > {user[0]} | Score: {user[1]} | Fase: {user[2]}")
    else:
        print(" ⏳ Esperando leads calientes...")

    print("-" * 45)
    conn.close()


if __name__ == "__main__":
    reporte_pulpo()
