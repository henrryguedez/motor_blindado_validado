import argparse
import datetime
import sys

# Configuración de recepción de datos
parser = argparse.ArgumentParser()
parser.add_argument("--nombre", help="Nombre del lead")
parser.add_argument("--interes", help="Nicho de interés")
parser.add_argument("--telefono", help="Teléfono del lead")
args = parser.parse_args()


def registrar_y_responder():
    # Validar datos recibidos
    nombre = args.nombre if args.nombre else "Prospecto"
    interes = args.interes if args.interes else "General"
    telefono = args.telefono if args.telefono else "Sin Numero"
    fecha = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Lógica Estratégica de Venta
    if "ingles" in interes.lower():
        mensaje = f"¡Hola {nombre}! 🚀 He visto tu interés en Inglés en 30 días. ¿Listo para el siguiente paso?"
    else:
        mensaje = f"Hola {nombre}, un gusto saludarte. Soy el asistente de Neovry Hub. ¿En qué podemos ayudarte?"

    # GUARDAR EN BASE DE DATOS DE SEGUIMIENTO (leads_seguimiento.txt)
    try:
        with open("leads_seguimiento.txt", "a", encoding="utf-8") as f:
            f.write(
                f"[{fecha}] {nombre} | {telefono} | {interes} | RESPUESTA: {mensaje}\n"
            )
    except Exception as e:
        pass  # Silenciar errores de escritura para no frenar el flujo

    # Enviamos la respuesta de vuelta al Hub
    print(mensaje)


if __name__ == "__main__":
    # Si se pasan argumentos, procesar el lead. Si no, mostrar inicio.
    if len(sys.argv) > 1:
        registrar_y_responder()
    else:
        print("[SISTEMA]: Interfaz Profesional Activada. Modo Operativo... ✅")
