const express = require('express');
const { exec } = require('child_process');
const app = express();
app.use(express.json());

app.post('/webhook', (req, res) => {
    const { nombre, telefono, interes } = req.body;
    console.log('\n🔔 LEAD:', nombre, '|', telefono);
    const cmd = `python motor_ia_v3.py --nombre "${nombre}" --interes "${interes}" --telefono "${telefono}"`;
    exec(cmd, (err, stdout) => {
        if (!err) console.log('🤖 IA RESPONDIÓ:', stdout.trim());
    });
    res.status(200).send({ status: 'OK' });
});

app.listen(3000, () => {
    console.log('\n✅ BÚNKER TOTALMENTE OPERATIVO EN PUERTO 3000');
});
