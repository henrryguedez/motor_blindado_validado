import sqlite3
import os


class NeovryCerebro:
    def __init__(self):
        self.db_path = os.path.expanduser("~/.neovry_vcv.db")

    def clasificar_lead(self, id_usuario, interaccion):
        score_puntos = 0
        palabras_clave = [
            "precio",
            "comprar",
            "inscripcion",
            "pago",
            "cuanto",
            "info",
            "costo",
            "valor",
        ]

        for palabra in palabras_clave:
            if palabra in interaccion.lower():
                score_puntos += 2

        if score_puntos > 0:
            self.actualizar_score(id_usuario, score_puntos)

    def actualizar_score(self, id_usuario, puntos):
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        try:
            # Usamos el nombre exacto de tu columna: id_usuario
            cur.execute(
                "UPDATE usuarios SET score = score + ?, fase = 'interesado' WHERE id_usuario = ?",
                (puntos, id_usuario),
            )
            if cur.rowcount == 0:
                print(f"⚠️ El usuario {id_usuario} no existe en la base de datos.")
            else:
                conn.commit()
                print(
                    f"🧠 Cerebro: Score actualizado para {id_usuario} (+{puntos} pts)."
                )
        except Exception as e:
            print(f"❌ Error técnico: {e}")
        finally:
            conn.close()


if __name__ == "__main__":
    print("🐙 Pulpo Neovry: Sincronizado con columna 'id_usuario'.")
