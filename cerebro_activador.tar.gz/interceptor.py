import sqlite3


def registrar_cliente():
    conn = sqlite3.connect("nbuilder.db")
    cursor = conn.cursor()
    cursor.execute(
        """CREATE TABLE IF NOT EXISTS prospectos 
        (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, telefono TEXT, curso TEXT, fecha DATETIME DEFAULT CURRENT_TIMESTAMP)"""
    )

    print("\n--- 📝 REGISTRO DE CLIENTE REAL ---")
    nombre = input("Escriba el nombre del cliente: ")
    tel = input("Escriba el teléfono (ej: 584120000000): ")
    curso = "Repostería Casera Online"

    cursor.execute(
        "INSERT INTO prospectos (nombre, telefono, curso) VALUES (?,?,?)",
        (nombre, tel, curso),
    )
    conn.commit()
    conn.close()
    print(f"\n✅ [BÚNKER] Guardado con éxito: {nombre}")


if __name__ == "__main__":
    while True:
        print("\n--- 📡 RADAR: REPOSTERÍA CASERA ONLINE ---")
        print("1. Registrar nuevo cliente")
        print("2. Salir")
        op = input("Seleccione una opción: ")
        if op == "1":
            registrar_cliente()
        elif op == "2":
            break
