const { default: makeWASocket, useMultiFileAuthState } = require('@whiskeysockets/baileys');
const qrcode = require('qrcode-terminal');
const fs = require('fs');

async function disparar() {
    const { state, saveCreds } = await useMultiFileAuthState('./auth_info_baileys');
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        syncFullHistory: false,
        browser: ["NEORVRY-SYSTEM", "Chrome", "1.0.0"]
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, qr } = update;
        if (qr) {
            console.clear();
            console.log('🚀 ESCANEA PARA ACTIVAR ENVÍOS:');
            qrcode.generate(qr, { small: true });
        }
        if (connection === 'open') {
            console.log('✅ MOTOR CONECTADO. INICIANDO DISPARO...');
            // Aquí el sistema leería prueba_leads.txt y mandaría el mensaje
            // Por seguridad, primero conectamos.
        }
    });
}
disparar();
