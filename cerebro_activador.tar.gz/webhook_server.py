from flask import Flask, request, jsonify
import time

app = Flask(__name__)
VENTAS_FILE = "ventas.txt"


@app.route("/webhook", methods=["POST"])
def receive_data():
    try:
        data = request.json
        # Extraemos datos (ajustado para Hotmart/Meta)
        cliente = data.get("name") or data.get("first_name") or "Cliente Nuevo"
        monto = data.get("amount") or data.get("price") or "0.00"

        # Formateamos para que el Bot lo reconozca
        registro = f"{time.strftime('%Y-%m-%d %H:%M:%S')} | {cliente} | {monto}\n"

        with open(VENTAS_FILE, "a") as f:
            f.write(registro)

        print(f"✅ WEBHOOK: Venta recibida de {cliente} por ${monto}")
        return jsonify({"status": "success"}), 200
    except Exception as e:
        print(f"❌ ERROR WEBHOOK: {e}")
        return jsonify({"status": "error"}), 400


if __name__ == "__main__":
    # Corremos en el puerto 5000 como configuraste originalmente
    app.run(host="0.0.0.0", port=8080)
