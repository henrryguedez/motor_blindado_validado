import logging
import json
import os
import random
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, 
    CommandHandler, 
    CallbackQueryHandler, 
    ContextTypes,
    PicklePersistence
)

# 1. CONFIGURACIÓN QUIRÚRGICA
TOKEN = '8658877853:AAE9MDxujiGgwdvYwNY0BFVmmYNyiPF2U20' 
ADMIN_ID = 5747657053
DB_FILE = "leads_neovry.json"

# Nichos con Beneficios Reales e Inyectados
LINKS = {
    "ingles": {"url": "https://go.hotmart.com/O97256329R", "beneficio": "Metodología bilingüe acelerada"},
    "reposteria": {"url": "https://go.hotmart.com/E93815520A", "beneficio": "Plantillas de costeo profesional"},
    "canina": {"url": "https://go.hotmart.com/I100829943N", "beneficio": "Guía de adiestramiento en casa"},
    "elite": {"url": "https://hotm.art/activador_elite", "beneficio": "Acceso total al ecosistema Neorvry"}
}

# 2. MOTOR DE PERSISTENCIA (Para no perder leads)
def guardar_lead(user_id, user_data):
    try:
        leads = {}
        if os.path.exists(DB_FILE):
            with open(DB_FILE, 'r') as f:
                leads = json.load(f)
        
        user_id_str = str(user_id)
        if user_id_str not in leads:
            leads[user_id_str] = {"fecha_registro": str(datetime.now())}
        
        leads[user_id_str].update(user_data)
        
        with open(DB_FILE, 'w') as f:
            json.dump(leads, f, indent=4)
    except Exception as e:
        print(f"⚠️ Error en DB: {e}")

# 3. RE-MARKETING AUTOMÁTICO (La Magia del Cierre)
async def follow_up_callback(context: ContextTypes.DEFAULT_TYPE):
    job = context.job
    try:
        msg = (
            f"🎁 **¡ATENCIÓN {job.data['nombre']}!**\n\n"
            f"Tu bono exclusivo de *'{job.data['beneficio']}'* está a punto de expirar.\n"
            "El sistema detecta que no has completado tu registro ELITE. ¿Te ayudo con el link?"
        )
        kb = [[InlineKeyboardButton("🔥 RECLAMAR MI BONO AHORA", callback_data='info_elite')]]
        await context.bot.send_message(chat_id=job.chat_id, text=msg, reply_markup=InlineKeyboardMarkup(kb), parse_mode='Markdown')
    except:
        pass

# 4. MANEJADORES DE INTERFAZ
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    kb = [
        [InlineKeyboardButton("📚 Inglés", callback_data='n_ingles'), InlineKeyboardButton("🎂 Repostería", callback_data='n_reposteria')],
        [InlineKeyboardButton("🐕 Canina", callback_data='n_canina')],
        [InlineKeyboardButton("🔥 ¡ACCESO ELITE!", callback_data='info_elite')]
    ]
    await update.message.reply_text(
        f"✨ **SISTEMA NEORVRY v12.1**\n\nMaestro {user.first_name}, selecciona el camino que vamos a escalar hoy:",
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode='Markdown'
    )

async def handle_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = query.from_user
    await query.answer()
    
    # A. SELECCIÓN DE NICHO
    if query.data.startswith('n_'):
        nicho = query.data.split('_')[1]
        guardar_lead(user.id, {"nicho": nicho, "paso": "interesado", "nombre": user.first_name})
        
        await query.edit_message_text(
            f"🔍 **ANÁLISIS DE MERCADO: {nicho.upper()}**\n\n"
            "Detecto una alta demanda en este sector. ¿Quieres activar tu **Bono de Acción Rápida** ahora?",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🚀 OBTENER ACCESO + BONO", callback_data=f'pre_{nicho}')]]),
            parse_mode='Markdown'
        )

    # B. GATILLO DE ESCASEZ REAL
    elif query.data.startswith('pre_'):
        nicho = query.data.split('_')[1]
        cupos = random.randint(2, 5)
        await query.edit_message_text(
            f"⚠️ **ALERTA DE CUPOS LIMITADOS**\n\nSolo quedan **{cupos} accesos** disponibles para {nicho.capitalize()} con el bono incluido.\n\n"
            "¿Confirmas que tienes el compromiso para iniciar hoy?",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✅ SÍ, ESTOY LISTO", callback_data=f'elite_{nicho}')]]),
            parse_mode='Markdown'
        )

    # C. CIERRE MAESTRO Y ENTREGA
    elif query.data.startswith('elite_'):
        nicho = query.data.split('_')[1]
        data = LINKS.get(nicho, LINKS["elite"])
        
        guardar_lead(user.id, {"status": "CLIC_LINK", "ultimo_nicho": nicho})

        # PROGRAMAR SEGUIMIENTO EN 24 HORAS
        context.job_queue.run_once(
            follow_up_callback, 
            86400, 
            chat_id=user.id, 
            data={'nombre': user.first_name, 'beneficio': data['beneficio']}
        )
        
        await query.edit_message_text(
            f"💎 **ACCESO AUTORIZADO.**\n\n"
            f"Tu bono activo: *{data['beneficio']}*.\n\n"
            "⚠️ *Nota: Este link es único para tu usuario y expira pronto.*",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔓 ACTIVAR AHORA", url=data['url'])]]),
            parse_mode='Markdown'
        )

# 5. PANEL DE ADMIN
async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID: return
    try:
        with open(DB_FILE, 'r') as f: leads = json.load(f)
        await update.message.reply_text(f"📊 **MÉTRICAS**\nTotal Leads: {len(leads)}\nObjetivo: $1,000,000")
    except: await update.message.reply_text("DB Vacía o con errores.")

if __name__ == '__main__':
    # Persistencia para no perder nada si Termux se cierra
    persistence = PicklePersistence(filepath="neovry_persistence.pickle")
    
    app = ApplicationBuilder().token(TOKEN).persistence(persistence).build()
    
    app.add_handler(CommandHandler('start', start))
    app.add_handler(CommandHandler('admin', admin))
    app.add_handler(CallbackQueryHandler(handle_buttons))
    
    print("\n[MAGIA CORREGIDA] NEORVRY v12.1 OPERANDO.\n")
    app.run_polling(drop_pending_updates=True)

