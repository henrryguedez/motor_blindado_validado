#!/bin/bash
echo "🔍 MONITOR PRO FIXED - neovry_productos API"

declare -i last_lines=0
while true; do
  lines=$(wc -l < ventas.txt 2>/dev/null || echo 0)
  if [ $lines -gt $last_lines ]; then
    new_line=$(tail -n +$((last_lines+1)) ventas.txt | head -1)
    echo "💰 VENTA NUEVA: $new_line"
    
    # Usar tu API REAL
    tag=$(echo "$new_line" | cut -d'|' -f4 | tr '[:upper:]' '[:lower:]')
    producto=$(curl -s "localhost:8080/buscar?q=$tag" | jq -r '.nombre // empty' 2>/dev/null)
    
    if [ "$producto" != "null" ] && [ -n "$producto" ]; then
      echo "   📦 Producto: $producto"
    else
      echo "   📦 Sin producto"
    fi
    
    last_lines=$lines
  fi
  sleep 3
done
