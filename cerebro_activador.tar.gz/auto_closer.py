import os
import time
import sys
from datetime import datetime

G, R, Y, C, M, W = "\033[92m", "\033[91m", "\033[93m", "\033[96m", "\033[95m", "\033[0m"


def identificar_comision(producto):
    prod = producto.lower()
    if "ingles" in prod or "afiliado" in prod:
        return 50.00, "Afiliado"
    elif "torta" in prod or "caser" in prod:
        return 15.00, "Venta Directa"
    else:
        return 10.00, "General"


def auto_closer():
    os.system("clear")
    print(f"{M}╔══════════════════════════════════════╗")
    print(f"║     ✨ NEORVRY QUANTUM-CLOSER        ║")
    print(f"╚══════════════════════════════════════╝{W}")

    if not os.path.exists("leads_bunker.txt"):
        return

    with open("leads_bunker.txt", "r") as f:
        leads = f.readlines()

    if not leads:
        print(f"{Y}[!] Búnker vacío.{W}")
        input("\nPresiona Enter...")
        return

    proximo = leads.pop(0)
    datos = proximo.split("|")
    nombre_lead = datos[2].strip() if len(datos) > 2 else "Anonimo"
    producto_lead = datos[3].strip() if len(datos) > 3 else "General"

    monto, tipo = identificar_comision(producto_lead)

    # GUARDAR EN BITÁCORA DE VICTORIAS
    fecha = datetime.now().strftime("%d/%m/%Y")
    with open("victorias.txt", "a") as f_v:
        f_v.write(f"{fecha}|{nombre_lead}|{monto}\n")

    print(f"{C}>> Liquidando: {nombre_lead} ({tipo}){W}")
    time.sleep(1)

    with open("leads_bunker.txt", "w") as f:
        f.writelines(leads)

    print(f"\n{G}💰 ${monto} USD TRANSFERIDOS A VICTORIAS{W}")
    input(f"\n{M}>> Sincronizar...{W}")


if __name__ == "__main__":
    auto_closer()
