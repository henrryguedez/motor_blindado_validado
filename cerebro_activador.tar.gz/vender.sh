#!/bin/bash
NOMBRE=$1
NICHO=$2

echo "🚀 OPERATIVO TOTAL: Iniciando producción para $NOMBRE..."

# 1. GENERAR IMAGEN Y AUDIO (Ya los tenemos configurados)
node -e "require('./crear_ia.cjs').generarImagenIA('$NICHO')"
node -e "require('./crear_imagen.cjs').generarOfertaPersonalizada('$NOMBRE', 'temp_ia')"
node -e "require('./crear_voz.cjs').generarVoz('$NOMBRE', '$NICHO')"

# 2. ENSAMBLAR VIDEO
bash crear_video.sh "$NOMBRE"

# 3. MOVER A GALERÍA
FECHA=$(date +%H%M%S)
cp assets/video_$NOMBRE.mp4 /sdcard/Download/VIDEO_OFERTA_${NOMBRE}_${FECHA}.mp4

echo "🔥 ¡PROCESO DE ÉLITE COMPLETADO!"
echo "🎥 Video enviado a Galería: VIDEO_OFERTA_${NOMBRE}_${FECHA}.mp4"
