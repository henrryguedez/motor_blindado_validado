const { default: makeWASocket, useMultiFileAuthState } = require("@whiskeysockets/baileys");
const pino = require("pino");

async function enviarL99(numero, mensaje) {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    const sock = makeWASocket({
        auth: state,
        logger: pino({ level: "silent" }),
        printQRInTerminal: false
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
        const { connection } = update;
        if (connection === 'open') {
            const id = `${numero}@s.whatsapp.net`;
            await sock.sendMessage(id, { text: mensaje });
            console.log(`[L99] Mensaje enviado a ${numero}`);
            process.exit(0);
        }
    });
}

const args = process.argv.slice(2);
if (args.length >= 2) {
    enviarL99(args[0], args[1]);
} else {
    console.log("Uso: node enviar_L99.js <numero> <mensaje>");
    process.exit(1);
}
