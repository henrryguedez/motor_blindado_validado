from respuesta_maestra import RespuestaNeovry

# Inicializamos el motor actualizado
pulpo = RespuestaNeovry()

# Datos del "Cliente de Oro"
info_nicho = {
    "nombre": "Curso de Repostería Casera",
    "link": "https://hotmart.com/tu-link",
}
score_cliente = 9

# Disparamos la respuesta
respuesta = pulpo.generar(score_cliente, info_nicho)

print("\n" + "=" * 40)
print("🤖 SIMULACIÓN DE RESPUESTA MAESTRA")
print("=" * 40)
print(f"RESULTADO: \n\n{respuesta}")
print("=" * 40 + "\n")
