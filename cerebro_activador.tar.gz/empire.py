import os
import time

G, R, B, C, Y, W = "\033[92m", "\033[91m", "\033[94m", "\033[96m", "\033[93m", "\033[0m"


def ejecutar(archivo, nombre):
    if os.path.exists(archivo):
        os.system(f"python {archivo}")
    else:
        print(f"\n{R}[!] ERROR: '{archivo}' no encontrado.{W}")
        time.sleep(2)


def empire_r22():
    while True:
        os.system("clear")
        print(f"{G}=================================================={W}")
        print(f"{Y}   EMPIRE R22 {W}|{G} OBJETIVO: $1M {W}|{C} ENVIADOS: 0{W}")
        print(f"{G}=================================================={W}")
        print(f"{B} 1:{W} Atacar (CRM)   {B} 2:{W} Enlaces    {B} 3:{W} Mentor")
        print(
            f"{B} 4:{W} Ver Leads      {B} 5:{W} Cierre     {R} 6: Victorias  7: Salir{W}"
        )
        print(f"{G}=================================================={W}")

        op = input(f"{C}➤ {W}").lower()

        if op == "1":
            ejecutar("crm_pro.py", "CRM")
        elif op == "2":
            ejecutar("abrir_wa.py", "Enlaces")
        elif op == "3":
            ejecutar("mentor.py", "Mentor")
        elif op == "4":
            ejecutar("database_helper.py", "Leads")
        elif op == "5":
            ejecutar("auto_closer.py", "Cierre")
        elif op == "6":
            ejecutar("bitacora.py", "Victorias")
        elif op == "7" or op == "salir":
            break
        else:
            print(f"{R}Inválido.{W}")
            time.sleep(1)


if __name__ == "__main__":
    empire_r22()
