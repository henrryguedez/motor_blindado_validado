#!/bin/bash
# Uso: bash crear_video.sh "Nombre"

NOMBRE=$1
IMAGEN="assets/oferta_${NOMBRE}.jpg"
AUDIO="assets/audio_${NOMBRE}.mp3"
SALIDA="assets/video_${NOMBRE}.mp4"

echo "🎬 NEOVRY HUB: Renderizando video para ${NOMBRE}..."

# Comando maestro de FFmpeg: 
# Crea un video de 5 segundos con zoom suave a partir de la imagen y le añade el audio
ffmpeg -y -loop 1 -i "$IMAGEN" -i "$AUDIO" -filter_complex \
"[0:v]scale=1280:1280,zoompan=z='min(zoom+0.0015,1.5)':d=125:s=720x720[v]" \
-map "[v]" -map 1:a -c:v libx264 -tune stillimage -c:a aac -b:a 192k -pix_fmt yuv420p -shortest "$SALIDA"

echo "✅ VIDEO LISTO: $SALIDA"
