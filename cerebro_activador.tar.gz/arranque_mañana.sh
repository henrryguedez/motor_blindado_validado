#!/bin/bash
echo "--- REPORTE DIARIO NEORVRY ---" >> ~/log_bot.txt
date >> ~/log_bot.txt
echo "Estado: Sistema Blindado y Operativo" >> ~/log_bot.txt
echo "Leads del día: $(sqlite3 nbuilder.db 'SELECT COUNT(*) FROM leads;')" >> ~/log_bot.txt
echo "----------------------------" >> ~/log_bot.txt
