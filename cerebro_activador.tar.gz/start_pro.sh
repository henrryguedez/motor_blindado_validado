#!/bin/bash
pkill -f neovry_pro.py || true
nohup python3 neovry_pro.py > pro.log 2>&1 &
echo $! > pro.pid
sleep 3
curl -s localhost:8080/stats | jq . || echo "✅ NEOVRY PRO ACTIVO!"
