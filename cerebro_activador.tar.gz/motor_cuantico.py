#!/usr/bin/env python3
import re, unicodedata, asyncio, json, logging, difflib
from collections import defaultdict, deque
from pathlib import Path
from typing import Dict, List
from dataclasses import dataclass
from notificar_lead import enviar_alerta 

logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class LeadScore:
    categoria: str
    score_total: float
    urgency: float
    predictive: int

class MotorCuanticoV10:
    def __init__(self):
        self.umbral = 72
        self.biblioteca = {
            "inscripcion": ["inscrip", "inscribir", "anotarme", "entrar", "comprar", "cupo", "link", "quiero", "info", "acceso", "ya", "ahora", "exclusivo"],
            "precio": ["precio", "costo", "valor", "cuanto", "pago", "oferta", "descuento"],
            "seguro": ["seguro", "confianza", "estafa", "miedo", "garantia", "protegido"],
            "temario": ["temario", "contenido", "aprender", "modulos", "clases", "curso"]
        }
        logger.info("🚀 V10.0 DEFINITIVA ACTIVADA | Neorvry Elite")

    def normalizar(self, t):
        t = "".join(c for c in unicodedata.normalize('NFD', t) if unicodedata.category(c) != 'Mn')
        return re.sub(r'\s+', ' ', t.lower().strip())

    def _urgency_detector(self, t):
        urgency_words = ["ya", "ahora", "ultimo", "hoy", "urgente"]
        count = sum(1 for w in urgency_words if re.search(rf"\b{w}\b", t))
        return min(count * 25, 50)

    async def analizar_mensaje(self, mensaje, numero="anon"):
        txt = self.normalizar(mensaje)
        scores = []
        for cat, palabras in self.biblioteca.items():
            fuzzy_sum = 0
            for p in palabras:
                sim = difflib.SequenceMatcher(None, p, txt).ratio() * 100
                if sim > self.umbral or p in txt:
                    fuzzy_sum = max(fuzzy_sum, sim)
            if fuzzy_sum > 0:
                urgency = self._urgency_detector(txt)
                total = fuzzy_sum + urgency
                predictive = min(int(total * 1.2), 100)
                scores.append(LeadScore(cat, total, urgency, predictive))

        if not scores: return {"categoria": "desconocido"}
        top = max(scores, key=lambda s: s.score_total)
        
        if top.categoria == "inscripcion":
            logger.warning(f"🔥 LEAD CALIENTE ({top.predictive}%): {numero}")
            try:
                await enviar_alerta(f"🎯 VENTA {top.predictive}% ({numero}): {mensaje[:50]}", 0.0)
            except Exception as e:
                logger.error(f"Error alerta: {e}")
        return {"categoria": top.categoria, "score": top.score_total, "predictivo": top.predictive}

if __name__ == "__main__":
    motor = MotorCuanticoV10()
    print("--- Probando Motor V10.1 ---")
    asyncio.run(motor.analizar_mensaje("QUIERO ENTRAR YA AL CURSO", "58412-V10"))

