import subprocess
import json


class RespuestaIA:
    def __init__(self, modelo="llama3.2:1b"):
        self.modelo = modelo

    def pensar(self, score, nicho, consulta_cliente):
        """
        Usa Llama 3.2 para generar una respuesta basada en el contexto del Pulpo.
        """
        prompt = f"""
        Eres un experto cerrador de ventas para Neovry.
        Contexto del cliente:
        - Nicho: {nicho['nombre']}
        - Interés (Score): {score}/10
        - Pregunta del cliente: "{consulta_cliente}"
        
        Tarea: Responde de forma breve, persuasiva y humana. 
        Si el Score es mayor a 7, invita al cierre con este link: {nicho['link']}.
        Si es menor, resuelve la duda y mantén la conversación viva.
        Respuesta:
        """

        try:
            # Llamada al modelo local (Ollama)
            proceso = subprocess.run(
                ["ollama", "run", self.modelo, prompt],
                capture_output=True,
                text=True,
                check=True,
            )
            return proceso.stdout.strip()
        except Exception as e:
            return f"Error conectando con el cerebro IA: {e}"


if __name__ == "__main__":
    print("🐙 Pulpo Neovry: Conexión con Llama 3.2 Establecida.")
