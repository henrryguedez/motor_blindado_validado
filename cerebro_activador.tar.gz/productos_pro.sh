#!/bin/bash
# PRODUCTOS PRO MANAGER v2.0

if [ "$1" == "stats" ]; then
    echo -e "\e[1;34m=== ESTADÍSTICAS DEL SISTEMA ===\e[0m"
    PRODUCTOS=$(grep -c "id" productos.json)
    echo -e "Productos Activos: \e[1;32m$PRODUCTOS\e[0m"
    echo -e "Último Update: \e[1;33m$(date '+%H:%M:%S')\e[0m"
    echo -e "Estado Webhook: \e[1;32mESCUCHANDO\e[0m"
    exit 0
fi

# Generación automática (lo que ya teníamos)
cat <<EOF > productos.json
{
  "version": "2.0",
  "productos": [
    {"id": 1, "nombre": "Inglés", "tags": ["ingles", "english"], "link": "https://go.hotmart.com/O97256329R"},
    {"id": 2, "nombre": "Repostería", "tags": ["reposteria", "tortas", "postres"], "link": "https://go.hotmart.com/O97256329R"},
    {"id": 3, "nombre": "Neovry Builder", "tags": ["sistema", "bot", "elite"], "link": "https://sistema-unificado.vercel.app"}
  ]
}
EOF
echo -e "\e[1;32m✅ Base de datos generada correctamente.\e[0m"
