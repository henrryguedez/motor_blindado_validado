from flask import Flask, render_template_string
from pathlib import Path
import time

app = Flask(__name__)
ROOT = Path(".")
DASHBOARD = """
<!DOCTYPE html>
<html><head><title>🦈 NEOVRY Dashboard</title>
<style>body{font-family:sans-serif;background:linear-gradient(135deg,#667eea,#764ba2);color:white;padding:20px;}
.card{background:rgba(255,255,255,0.1);border-radius:15px;padding:20px;margin:10px 0;}
.metric{font-size:2.5em;font-weight:bold;}
</style></head><body>
<div class="card"><h1>💰 NEOVRY V10 LIVE</h1>
<p>Ventas hoy: <span class="metric">{{ventas}}</span></p>
<p>Leads: <span class="metric">{{leads}}</span></p></div>

<div class="card">
<h2>📊 Logs Recientes</h2>
<pre>{{logs}}</pre>
</div>

<script>setInterval(()=>location.reload(),10000);</script>
</body></html>
"""


def leer_logs():
    logs = []
    try:
        with open("ventas.log", "r") as f:
            logs = f.readlines()[-20:]
    except:
        logs = ['No ventas.log | Crea con: echo "test" > ventas.log']
    return "".join(logs)


@app.route("/")
def home():
    return render_template_string(DASHBOARD, ventas="47", leads="12", logs=leer_logs())


if __name__ == "__main__":
    print("🌊 Dashboard → http://127.0.0.1:8081")
    app.run(host="0.0.0.0", port=8081, debug=False, use_reloader=False)
