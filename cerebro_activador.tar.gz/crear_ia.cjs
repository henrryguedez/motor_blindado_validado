const axios = require('axios');
const fs = require('fs');
const path = require('path');

async function generarImagenIA(prompt_cliente) {
    console.log(`🧠 IA NEOVRY: Imaginando "${prompt_cliente}"...`);
    
    // Usamos Pollinations: Rápido, Gratuito y sin errores 404
    const promptEscapado = encodeURIComponent(prompt_cliente);
    const API_URL = `https://image.pollinations.ai/prompt/${promptEscapado}?width=1080&height=1080&nologo=true`;
    
    try {
        const response = await axios({
            method: 'get',
            url: API_URL,
            responseType: 'arraybuffer',
            timeout: 30000 
        });

        const rutaTemp = path.join(process.cwd(), 'assets', 'temp_ia.jpg');
        fs.writeFileSync(rutaTemp, response.data);
        console.log("🎨 ¡Imagen creada instantáneamente!");
        return 'temp_ia'; 
    } catch (err) {
        console.error("❌ Error en la conexión:", err.message);
        return undefined;
    }
}

module.exports = { generarImagenIA };
