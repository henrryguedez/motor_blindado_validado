import os

# Interfaz de Alta Tecnología (Colores)
G, B, Y, C, R = "\033[92m", "\033[94m", "\033[93m", "\033[96m", "\033[0m"


def cargar_progreso():
    if not os.path.exists("progreso.txt"):
        return 0
    with open("progreso.txt", "r") as f:
        return int(f.read().strip())


def guardar_progreso(n):
    with open("progreso.txt", "w") as f:
        f.write(str(n))


def crear_mensaje(nombre):
    return f"\n{G}🚀 *SCRIPT ALPHA R22:* {nombre}{R}\n" + f"""
Hola {nombre}, te escribe el *Arquitecto Henrry*. Mi sistema detectó una falla en la rentabilidad de tu repostería. He habilitado un cupo legal desde Venezuela vía *Alianza Indetenible* y *Hotmart*. ¿Te envío el enlace?
"""


def obtener_enlace():
    return f"\n{B}✅ *NODOS DE INVERSIÓN (HOTMART):*{R}\n" + """
🔸 *Base ($25):* https://go.hotmart.com/Q90190219S?ap=b664
🔸 *Medio ($35):* https://go.hotmart.com/Q90190219S?ap=b8f5
🔸 *Full ($45):* https://go.hotmart.com/Q90190219S?ap=ec15
"""


def manejo_objeciones():
    return f"\n{Y}🛡️ *CONTRAATAQUE PSICOLÓGICO:*{R}\n" + """
"¿Cuánto dinero pierdes hoy por no optimizar? Esto es ingeniería financiera, no un gasto. ¿Activamos tu nodo?"
"""


enviados = cargar_progreso()
while True:
    print(
        f"\n{C}{'='*50}\n   EMPIRE R22 | OBJETIVO: $1M | ENVIADOS: {enviados}\n{'='*50}{R}"
    )
    accion = input(
        f"{B}1: Atacar | 2: Enlaces | 3: Objeciones | 5: Cierre Exitoso | 'salir'{R}\n> "
    )

    if accion == "1":
        nombre = input("Nombre del prospecto: ")
        print(crear_mensaje(nombre))
        enviados += 1
        guardar_progreso(enviados)
    elif accion == "2":
        print(obtener_enlace())
    elif accion == "3":
        print(manejo_objeciones())
    elif accion == "5":
        nombre = input("Nombre del alumno: ")
        with open("ventas_empire.txt", "a") as f:
            f.write(f"EXITO: {nombre}\n")
        print(f"\n{G}🏆 ¡VICTORIA DETECTADA! 🏆{R}")
        print(
            f"{G}Arquitecto Henrry, el primer ladrillo del Imperio ha sido colocado.{R}"
        )
        print(f"{C}Cliente {nombre} sincronizado con NEORVRY BUILDER EMPIRE.{R}")
    elif accion.lower() == "salir":
        print(f"{Y}Búnker R22 en modo hibernación. Esperando el amanecer.{R}")
        break
