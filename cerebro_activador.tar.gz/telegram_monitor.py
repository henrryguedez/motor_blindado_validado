import logging
import os
from datetime import datetime
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

# Configuración
TOKEN = "8658877853:AAE9MDxujiGgwdvYwNY0BFVmmYNyiPF2U20"
CHAT_ID = "6951875143"

logging.basicConfig(level=logging.INFO)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🚀 **Sistema Neovry v10.0 Online**\n\nMonitor activo. El camino al millón continúa.", 
        parse_mode='Markdown'
    )

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ahora = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    mensaje = f"📊 **Estado del Sistema**\n\n✅ Motor Cuántico: Operativo\n⏰ Hora: {ahora}\n📍 Ubicación: Termux Server"
    await update.message.reply_text(mensaje, parse_mode='Markdown')

def main():
    # Creamos la aplicación (sin el bloque async)
    app = Application.builder().token(TOKEN).build()
    
    # Añadimos los comandos
    app.add_handler(CommandHandler('start', start))
    app.add_handler(CommandHandler('status', status))
    
    print("🤖 Neovry Bot v10.0 está escuchando...")
    
    # Este método maneja su propio loop internamente sin conflictos
    app.run_polling(drop_pending_updates=True)

if __name__ == '__main__':
    main()

