while true
do
    echo "------------------------------------------"
    echo "🚀 INICIANDO NEOVRY HUB EN MODO PERSISTENTE"
    echo "------------------------------------------"
    node neorvry_hub.js
    echo "⚠️ Sistema caído. Reiniciando en 5 segundos..."
    sleep 5
done
