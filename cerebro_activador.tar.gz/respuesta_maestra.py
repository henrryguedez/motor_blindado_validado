import json
import random


class RespuestaNeovry:
    def __init__(self):
        with open("mensajes_vcv.json", "r", encoding="utf-8") as f:
            self.datos = json.load(f)
            # Cargamos la nueva estrategia del Drive si existe
            self.estrategia = self.datos.get("estrategia_drive_2026", {})
            self.mensajes = self.datos  # Referencia general

    def generar(self, score, nicho_info):
        # 1. Lógica de ALTO VALOR (Estrategia Drive 2026)
        if score >= 9:
            msj = self.estrategia.get("mensajes_clave", {}).get(
                "cierre", "Iniciando protocolo de cierre."
            )
            return f"🚀 {msj}\n\nAcceso prioritario a {nicho_info['nombre']}: {nicho_info['link']}"

        # 2. Lead Caliente
        elif score >= 7:
            msj = random.choice(
                self.mensajes.get("precios", ["Revisa nuestros precios aquí."])
            )
            return f"{msj}\n\nInscríbete aquí: {nicho_info['link']}"

        # 3. Lead Interesado (Usa el radar del Drive)
        elif score >= 4:
            bienvenida_drive = self.estrategia.get("mensajes_clave", {}).get(
                "bienvenida", ""
            )
            return f"{bienvenida_drive}\n\nVeo que te interesa {nicho_info['nombre']}. ¿Tienes alguna duda técnica?"

        # 4. Lead Nuevo
        else:
            return random.choice(
                self.mensajes.get("bienvenida", ["¡Hola! Bienvenido al sistema."])
            )


if __name__ == "__main__":
    print("🐙 Pulpo Neovry: Tentáculo de Respuesta ACTUALIZADO con Estrategia 2026.")
