#!/bin/bash
# GENERADOR DE COPYS ESTRATÉGICOS - NEORVRY BUILDER

clear
echo -e "\e[1;34m================================================\e[0m"
echo -e "\e[1;32m       ✍️  GENERADOR DE COPYS PERSUASIVOS       \e[0m"
echo -e "\e[1;34m================================================\e[0m"
echo "Selecciona el ángulo de venta:"
echo "1) ⚡ Rapidez (Aprende en 30 días)"
echo "2) 💼 Profesional (Inglés para el Trabajo)"
echo "3) ✈️ Viajero (Sobrevive en el extranjero)"
echo "------------------------------------------------"
read -p "➤ Opción: " ANGULO

echo -e "\nGenerando tu copy maestro...\n"
sleep 1

case $ANGULO in
    1)
        echo -e "\e[1;33m[COPY - ÁNGULO RAPIDEZ]\e[0m"
        echo "------------------------------------------------"
        echo "🔥 ¿Cansado de años en academias sin hablar ni una palabra?"
        echo "Olvida la gramática aburrida. Con mi método Neorvry,"
        echo "activarás tu fluidez en solo 30 días. 🚀"
        echo "Únete a la Elite Army y domina el idioma más importante del mundo."
        echo "👉 Haz clic aquí para empezar hoy mismo."
        ;;
    2)
        echo -e "\e[1;33m[COPY - ÁNGULO PROFESIONAL]\e[0m"
        echo "------------------------------------------------"
        echo "💼 Tu carrera tiene un techo y se llama 'No saber inglés'."
        echo "No pierdas más oportunidades de ascenso o empleos en dólares."
        echo "Aprende el inglés técnico y conversacional que los negocios exigen."
        echo "Mentoría directa y resultados en tiempo récord. 📈"
        echo "👉 Inscríbete aquí y escala tu sueldo."
        ;;
    3)
        echo -e "\e[1;33m[COPY - ÁNGULO VIAJERO]\e[0m"
        echo "------------------------------------------------"
        echo "✈️  Que el idioma no sea una barrera en tu próxima aventura."
        echo "Aprende a pedir comida, moverte por el aeropuerto y socializar"
        echo "sin miedo a quedarte en blanco. 🌍"
        echo "Inglés práctico para gente real. ¡Tu viaje empieza aquí!"
        echo "👉 Cupos limitados aquí."
        ;;
    *)
        echo "Opción no válida."
        ;;
esac

echo "------------------------------------------------"
read -p "Presiona Enter para volver al menú..."
