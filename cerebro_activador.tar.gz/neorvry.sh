#!/bin/bash
# NÚCLEO CENTRAL NEORVRY BUILDER PRO ⚡

while true; do
    clear
    echo -e "\e[1;34m================================================\e[0m"
    echo -e "\e[1;32m         NEORVRY BUILDER PRO - ACTIVE          \e[0m"
    echo -e "\e[1;34m================================================\e[0m"
    echo -e "\e[1;37m ESTADO: \e[1;32mONLINE\e[0m | \e[1;37mMETA: \e[1;33m$1,000,000\e[0m"
    echo -e "\e[1;34m------------------------------------------------\e[0m"
    echo " 1) 🚀 CRM PRO (Registrar Ventas)"
    echo " 2) 🌐 INICIAR WEBHOOK (Servidor Ventas)"
    echo " 3) 🤖 BOT WHATSAPP (neorvry_bot.py)"
    echo " 4) ⚙️  MOTOR JS (Ejecutar neorvry_motor.js)"
    echo " 5) 📊 VER TABLERO DE CONTROL"
    echo " 6) 📝 REVISAR VENTAS (ventas.txt)"
    echo " 7) ❌ APAGAR SISTEMA"
    echo -e "\e[1;34m------------------------------------------------\e[0m"
    read -p "➤ SELECCIÓN: " opt

    case $opt in
        1)
            python3 crm_pro.py
            ;;
        2)
            echo "Iniciando Webhook Server..."
            python3 webhook_server.py &
            sleep 2
            echo "Servidor en segundo plano (Port 5000)."
            read -p "Presione Enter para volver..."
            ;;
        3)
            python3 neorvry_bot.py
            ;;
        4)
            node neorvry_motor.js
            read -p "Presione Enter para volver..."
            ;;
        5)
            ./tablero.sh
            ;;
        6)
            echo -e "\n--- REGISTRO DE VENTAS ---"
            if [ -f ventas.txt ]; then
                tail -n 20 ventas.txt
            else
                echo "No hay ventas registradas aún."
            fi
            read -p "Presione Enter para volver..."
            ;;
        7)
            echo "Cerrando procesos y guardando sesión..."
            exit 0
            ;;
        *)
            echo "Opción inválida, Henry."
            sleep 1
            ;;
    esac
done
