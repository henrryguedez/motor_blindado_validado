try {
    console.log("Iniciando carga de módulos...");
    const sqlite3 = require('sqlite3');
    console.log("SQLite3 cargado.");
    const baileys = require('@whiskeysockets/baileys');
    console.log("Baileys cargado.");
    console.log("Todo está bien. El problema es tu script.");
} catch (err) {
    console.error("ERROR DETECTADO: " + err.message);
}
