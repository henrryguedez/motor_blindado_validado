cat > monitor_ventas_pro.py << 'EOF'
#!/usr/bin/env python3
import time
import os
import json
from datetime import datetime

# ========================================
# CONFIGURACIÓN NEOVRY PRO
# ========================================
VENTAS_FILE = "ventas.txt"
LOG_BOT = "log_bot.txt"
PRODUCTOS_FILE = "productos.json"

# NEOVRY PRO INTEGRADO
def buscar_producto_pro(query):
    """Busca productos automáticamente"""
    try:
        with open(PRODUCTOS_FILE, 'r') as f:
            data = json.load(f)
        q = query.lower()
        for p in data.get('productos', []):
            if (p.get('activo') and any(t.lower() in q for t in p['tags'])):
                return f"🔥 *{p['nombre']}*

{p.get('descripcion', '')}
👉 {p['link']}"
    except:
        pass
    return None

def enviar_notificacion(cliente, monto, producto=None):
    """Notificación mejorada con productos"""
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    mensaje = f"🚀 ¡NUEVA VENTA! | Cliente: {cliente} | Monto: ${monto}"
    
    if producto:
        mensaje += f" | Producto: {producto}"
    
    print(f"
[{timestamp}] [BOT]: {mensaje}")
    
    with open(LOG_BOT, "a", encoding='utf-8') as l:
        l.write(f"{timestamp} - Notificación: {mensaje}
")

def procesar_linea_ventas(linea):
    """Procesa línea de ventas y busca productos relacionados"""
    if "|" not in linea:
        return
    
    parts = [p.strip() for p in linea.strip().split("|")]
    if len(parts) >= 3:
        cliente = parts[1]
        monto = parts[2]
        
        # Buscar producto relacionado
        query = " ".join(parts[3:]).lower() if len(parts) > 3 else cliente.lower()
        producto = buscar_producto_pro(query)
        
        enviar_notificacion(cliente, monto, producto[:100] if producto else None)

def monitorear_ventas():
    """Monitorea ventas EN TIEMPO REAL + Productos PRO"""
    print("\u001B[1;36m🚀 NEOVRY VENTAS PRO - Monitor Activo...\u001B[0m")
    
    # Crear archivos si no existen
    for file in [VENTAS_FILE, LOG_BOT]:
        if not os.path.exists(file):
            open(file, 'w').close()
    
    last_size = os.path.getsize(VENTAS_FILE)
    
    try:
        while True:
            if os.path.exists(VENTAS_FILE):
                current_size = os.path.getsize(VENTAS_FILE)
                if current_size > last_size:
                    with open(VENTAS_FILE, "r", encoding='utf-8') as f:
                        f.seek(last_size)
                        lineas = f.readlines()
                        for linea in lineas:
                            procesar_linea_ventas(linea)
                    last_size = current_size
            time.sleep(2)
    except KeyboardInterrupt:
        print("
\u001B[1;33m[SISTEMA]: Monitor detenido por usuario.\u001B[0m")
    except Exception as e:
        print(f"
\u001B[1;31m[ERROR]: {e}\u001B[0m")

if __name__ == "__main__":
    print("📊 Iniciando Neovry Ventas PRO...")
    print("📁 Monitoreando:", VENTAS_FILE)
    print("📊 Log:", LOG_BOT)
    print("🧠 Productos:", PRODUCTOS_FILE)
    print("-" * 50)
    monitorear_ventas()
EOF

chmod +x monitor_ventas_pro.py

# NEOVRY V4.0 MATRIX - 5 LÍNEAS
import requests
def neovry_v4(mensaje):
    try:
        r = requests.get(f"http://localhost:8080/buscar?q={mensaje}", timeout=3)
        data = r.json()
        if data.get('encontrado'):
            return f"🤖 *V4 MATRIX*

{data['nombre']}
{data['descripcion']}
👉 {data['link']}"
    except: pass
    return "🔧 *Neovry V4* Embudo AIDA → ¿Repuestos carro?"

# LÓGICA NUEVA (agregar donde procesas mensajes)
if any(x in mensaje.lower() for x in ['curso','producto','repuesto','carro']):
    resp = neovry_v4(mensaje)
    enviar_whatsapp(numero, resp)
