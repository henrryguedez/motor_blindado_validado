const axios = require('axios');
const fs = require('fs');
const path = require('path');

async function generarVoz(nombre, nicho) {
    console.log(`🎙️ NEOVRY HUB: Generando respuesta vocal para ${nombre}...`);
    
    // Texto que dirá el bot
    const texto = `Hola ${nombre}, un gusto saludarte. Aquí tienes la oferta especial que preparamos para ti sobre nuestro curso de ${nicho}. ¡Espero que te guste!`;
    
    // Usamos una API de TTS gratuita y rápida
    const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(texto)}&tl=es&client=tw-ob`;

    try {
        const response = await axios({
            method: 'get',
            url: url,
            responseType: 'arraybuffer'
        });

        const rutaAudio = path.join(process.cwd(), 'assets', `audio_${nombre}.mp3`);
        fs.writeFileSync(rutaAudio, response.data);
        console.log("🔊 ¡Audio generado con éxito!");
        return rutaAudio;
    } catch (err) {
        console.error("❌ Error en la boca del sistema:", err.message);
        return undefined;
    }
}

module.exports = { generarVoz };
