import QRCode from 'qrcode';

// Tu link de Hotmart para Repostería
const url = 'https://go.hotmart.com/Q90190219S'; 
const nombreArchivo = 'qr_reposteria.png';

try {
    await QRCode.toFile(nombreArchivo, url, {
        errorCorrectionLevel: 'H',
        color: {
            dark: '#000000', 
            light: '#FFFFFF'
        }
    });
    console.log('✅ QR de Repostería generado con éxito como qr_reposteria.png');
} catch (err) {
    console.error('❌ Error:', err);
}

