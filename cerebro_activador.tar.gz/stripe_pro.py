import os
import stripe
from flask import Flask, request, jsonify

app = Flask(__name__)
stripe.api_key = "sk_test_51HVAC5taJQpBbILJ1ptLHqz"  # ✅ TEST FUNCIONA


@app.route("/create-payment", methods=["POST"])
def create_payment():
    try:
        data = request.get_json(force=True)
        cliente = data["cliente"]
        monto = float(data["monto"])
        print(f"✅ REGISTRANDO: {cliente} ${monto}")
        os.system(f"echo 'Stripe: {cliente} ${monto}' >> ventas.txt")

        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[
                {
                    "price_data": {
                        "currency": "usd",
                        "product_data": {"name": f"Neorvry {cliente}"},
                        "unit_amount": int(monto * 100),
                    },
                    "quantity": 1,
                }
            ],
            mode="payment",
            success_url="https://wa.me/584167443305?text=Pago%20exitoso",
            cancel_url="https://wa.me/584167443305?text=Pago%20cancelado",
        )
        print(f"💳 LINK: {session.url}")
        return jsonify({"url": session.url, "cliente": cliente})
    except Exception as e:
        print(f"❌ {e}")
        return jsonify({"error": str(e)}), 500


print("🚀 Stripe PRO listo!")
app.run(host="0.0.0.0", port=5001, debug=True)
