const obtenerRespuestaPro = (mensaje, score) => {
    const m = mensaje.toLowerCase();
    
    // Lógica de Links por Nicho
    if (m.includes('inglés') || m.includes('ingles')) {
        return "¡Excelente elección! Dominar el inglés abrirá tus puertas. Aquí tienes el acceso a 'Inglés en 30 días': https://go.hotmart.com/O97256329R";
    }
    if (m.includes('repostería') || m.includes('reposteria') || m.includes('pastel')) {
        return "¡Qué delicia! Aprende las mejores técnicas aquí. Este es el link de 'Repostería Casera': https://go.hotmart.com/Q90190219S";
    }
    if (m.includes('jabón') || m.includes('jabon')) {
        return "El negocio de los jabones es muy rentable. Aquí tienes el acceso al curso: https://go.hotmart.com/S104265518J";
    }
    if (m.includes('celular') || m.includes('reparar')) {
        return "Aprende una profesión de alta demanda. Aquí tienes el link de 'Reparación de Celulares': https://go.hotmart.com/W104890711Y";
    }
    if (m.includes('perro') || m.includes('gato') || m.includes('canina')) {
        return "¡Tu mascota te lo agradecerá! Mira el Mega Pack de recetas aquí: https://go.hotmart.com/I103365064U";
    }

    // Respuesta genérica si el score es alto pero no detectó nicho
    if (score >= 30) {
        return "¡Veo que estás listo para empezar! ¿Por cuál de nuestros sistemas te gustaría comenzar hoy?";
    }
    
    return "¡Qué tal! Soy el asistente de Neovry. ¿Te interesa aprender sobre inglés, repostería, jabones o reparación de celulares?";
};
