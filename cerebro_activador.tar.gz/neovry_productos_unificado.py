
import datetime

def buscar_producto(query):
    query = query.lower()
    try:
        with open('productos_alianza.txt', 'r') as f:
            for line in f:
                nombre, link = line.strip().split('|')
                if nombre.lower() in query:
                    log = f'{datetime.datetime.now()} | VENTA POTENCIAL: {nombre} | LINK: {link}'
                    print(log)
                    return {'nombre': nombre, 'link': link}
    except FileNotFoundError:
        return None
    return None
