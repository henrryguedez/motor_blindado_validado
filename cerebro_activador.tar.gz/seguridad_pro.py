import re
import datetime
import os

CONFIG = {
    "link_hotmart": "https://go.hotmart.com/TU_LINK_AQUI",
    "precio_oficial": "49.99",
    "log_file": "auditoria_seguridad.log"
}

def registrar_ajuste(tipo, original, corregido):
    fecha = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(CONFIG["log_file"], "a", encoding="utf-8") as f:
        f.write(f"[{fecha}] [{tipo}] | IA: {original[:30]}... | FIX: {corregido[:30]}...\n")

def escudo_neovry(texto_ia, historial_count=0):
    nuevo_texto = texto_ia
    if any(d in texto_ia.lower() for d in ["precio", "comprar", "info", "costo"]):
        if "hotmart.com" not in texto_ia:
            nuevo_texto += f"\n\n🚀 Acceso aquí: {CONFIG['link_hotmart']}"
            registrar_ajuste("LINK", texto_ia, nuevo_texto)
    return nuevo_texto

if __name__ == "__main__":
    print("🛡️ Escudo Neovry activo y protegiendo.")

