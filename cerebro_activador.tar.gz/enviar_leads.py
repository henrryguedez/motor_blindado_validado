import os
from datetime import datetime


def procesar_leads():
    if not os.path.exists("prueba_leads.txt"):
        print("❌ Error: prueba_leads.txt no existe.")
        return

    with open("prueba_leads.txt", "r") as f:
        leads = [line.strip() for line in f if line.strip()]

    if not leads:
        print("⚠️ No hay leads para procesar.")
        return

    fecha = datetime.now().strftime("%Y-%m-%d %H:%M")

    with open("log_envios.txt", "a") as log:
        for lead in leads:
            # Limpiar número de espacios, guiones y el +
            numero = (
                lead.split("|")[0].replace("+", "").replace(" ", "").replace("-", "")
            )
            log.write(f"{fecha} | {numero} | PENDIENTE_ENVIO\n")
            print(f"✅ Lead registrado en log: {numero}")

    print("\n--- PROCESO COMPLETADO ---")
    print("Los leads están listos en log_envios.txt para ser disparados.")


if __name__ == "__main__":
    procesar_leads()
