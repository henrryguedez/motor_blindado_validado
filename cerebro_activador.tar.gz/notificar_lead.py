import asyncio
import os
from telegram import Bot

# Datos de tu sistema Neovry
TOKEN = "8658877853:AAE9MDxujiGgwdvYwNY0BFVmmYNyiPF2U20"
CHAT_ID = "6951875143"

async def enviar_alerta(producto, monto=None):
    bot = Bot(token=TOKEN)
    monto_str = f" - *${monto}*" if monto else ""
    texto = f"🎯 **¡NUEVA CONVERSIÓN NEORVRY!**\n\n📦 Producto: {producto}{monto_str}\n🚀 Estado: Exitosa"
    
    async with bot:
        try:
            # Si tienes el audio alert.mp3 lo enviará, si no, solo el texto
            if os.path.exists('alert.mp3'):
                with open('alert.mp3', 'rb') as voice:
                    await bot.send_voice(chat_id=CHAT_ID, voice=voice)
            else:
                print("⚠️ Sin alert.mp3, enviando solo texto.")
        except Exception as e:
            print(f"Error con el audio: {e}")
        
        await bot.send_message(chat_id=CHAT_ID, text=texto, parse_mode='Markdown')
        print("✅ Notificación enviada a Telegram.")

if __name__ == '__main__':
    # Esto es solo para probarlo ahora mismo
    asyncio.run(enviar_alerta('Curso Inglés 30 Días', 50.0))

