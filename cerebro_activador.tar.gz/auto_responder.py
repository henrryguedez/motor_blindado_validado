import os
import time


def disparar_rafaga():
    print("\033[1;33m[🤖] ESCANEANDO LEADS ENTRANTES...\033[0m")
    time.sleep(2)

    # Tus dos números vinculados
    numeros = ["584167443305", "584245190932"]

    # Mensaje de Repostería (Basado en tus fotos)
    enlace = "https://go.hotmart.com/T93803645X?ap=0daf"
    mensaje = (
        "¡Hola! 🎂 Vi que te interesa el Masterclass de Repostería. Aquí tienes la info y el bono de descuento: "
        + enlace
    )

    print("\033[1;32m[✔] ACTIVANDO RÁFAGA A DOS TERMINALES...\033[0m")

    for num in numeros:
        print(f"\033[1;36m[🚀] DISPARANDO A: {num}...\033[0m")
        os.system(f"node enviar_wa.cjs '{num}' '{mensaje}'")
        time.sleep(1)

    print("\033[1;32m[✅] RÁFAGA COMPLETADA.\033[0m")


if __name__ == "__main__":
    disparar_rafaga()
