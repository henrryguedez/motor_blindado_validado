import sqlite3, random, sys, os
from datetime import datetime, timedelta
from pathlib import Path

DB_PATH = Path.home() / ".neovry_vcv.db"

# --- CONFIGURACIÓN DE COPY REPOSTERÍA ---
CONTENIDOS = {
    "VALOR": [
        "¡Tip de Oro! 🧁 El secreto de un bizcocho esponjoso es no sobrebatir la mezcla. ¡Pruébalo!",
        "¿Sabías que la temperatura de los huevos cambia la textura de tus cremas? Úsalos a ambiente. 🍰",
    ],
    "CONFIANZA": [
        "Nuestra técnica envolvente garantiza resultados gourmet, incluso si eres principiante. ✨",
        "Más de 500 alumnas ya están emprendiendo con estos diseños de tartas. ¡Tú eres la siguiente! 👩‍🍳",
    ],
    "VENTA": [
        "🚀 REPOSTERÍA ELITE: +100 recetas y decoración. De $47 a SOLO $27 HOY. Cupo limitado: https://go.hotmart.com/T93803645X?ap=0daf",
        "🎂 ¡ÚLTIMA CHANCE! Domina la repostería por solo $27. Acceso vitalicio aquí: https://go.hotmart.com/T93803645X?ap=0daf",
    ],
    "RECUERDO": [
        "¿Aún tienes dudas con el manual de Repostería? 🍰 La oferta de $27 expira pronto.",
        "No dejes pasar el descuento. Tu emprendimiento dulce empieza aquí: https://go.hotmart.com/T93803645X?ap=0daf",
    ],
}


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""CREATE TABLE IF NOT EXISTS usuarios (
        id_usuario TEXT PRIMARY KEY, fase TEXT DEFAULT 'VALOR',
        score INTEGER DEFAULT 0, nombre TEXT, ultima_interaccion TEXT,
        ultimo_seguimiento TEXT, comprado BOOLEAN DEFAULT FALSE)""")
    conn.commit()
    conn.close()


def ejecutar_flujo(id_user, msg="", nombre="Amigo"):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    ahora = datetime.now().isoformat()

    c.execute(
        "INSERT OR IGNORE INTO usuarios (id_usuario, nombre, ultima_interaccion) VALUES (?, ?, ?)",
        (id_user, nombre, ahora),
    )
    c.execute(
        "SELECT fase, score, comprado FROM usuarios WHERE id_usuario=?", (id_user,)
    )
    fase, score, comprado = c.fetchone()

    intent = any(
        p in msg.lower() for p in ["precio", "cuanto", "info", "comprar", "costo"]
    )

    if intent:
        res = random.choice(CONTENIDOS["VENTA"])
        fase, score = "VENTA", score + 10
    elif fase == "VALOR":
        res = f"¡Hola {nombre}! " + random.choice(CONTENIDOS["VALOR"])
        fase, score = "CONFIANZA", score + 5
    elif fase == "CONFIANZA":
        res = random.choice(CONTENIDOS["CONFIANZA"])
        fase, score = "VENTA", score + 5
    else:
        res = random.choice(CONTENIDOS["VENTA"])
        score += 2

    c.execute(
        "UPDATE usuarios SET fase=?, score=?, ultima_interaccion=? WHERE id_usuario=?",
        (fase, score, ahora, id_user),
    )
    conn.commit()
    conn.close()
    return f"\n[NEOVRY BLACK OPS] -> {res}"


if __name__ == "__main__":
    if len(sys.argv) >= 3:
        # El primer argumento es el ID y el resto es el mensaje
        target = sys.argv[1]
        mensaje = " ".join(sys.argv[2:])
        print(ejecutar_flujo(target, msg=mensaje))
    else:
        print("\n[!] Uso: python vcv_elite.py <ID_USUARIO> <MENSAJE>")
        print("[!] Ejemplo: python vcv_elite.py 584123456789 precio\n")
