#!/data/data/com.termux/files/usr/bin/bash
TURQUESA='\e[1;96m'
WHITE='\e[1;97m'
GREEN='\e[1;92m'
YELLOW='\e[1;93m'
NC='\e[0m'

clear
echo -e "${TURQUESA}🚀 ARTILLERÍA DE CIERRE | NEORVRY AI${NC}"
echo -e "${WHITE}------------------------------------------${NC}"
echo -e "${YELLOW}1) COPY: Inglés en 30 días (Cierre Rápido)${NC}"
echo -e "${YELLOW}2) COPY: Repostería Casera (Emprendimiento)${NC}"
echo -e "${YELLOW}3) Gancho: Regalo / Lead Magnet${NC}"
echo -e "${YELLOW}4) Volver al Menú Maestro${NC}"
echo -e "${WHITE}------------------------------------------${NC}"
read -p "➤ Seleccione Munición: " art_opt

case $art_opt in
    1)
        echo -e "${GREEN}\n[COPY SELECCIONADO: INGLÉS EN 30 DÍAS]${NC}"
        echo "🛑 ¡Deja de estudiar gramática y empieza a HABLAR! 🗣️"
        echo "En solo 30 días, desbloquea tu oído y domina las frases que"
        echo "realmente se usan. Método garantizado para gente sin tiempo."
        echo "👇 ¡Toca el link y aprovecha el 50% de descuento HOY!"
        ;;
    2)
        echo -e "${GREEN}\n[COPY SELECCIONADO: REPOSTERÍA]${NC}"
        echo "🎂 De hobby a negocio rentable. Aprende repostería desde cero."
        echo "Inicia hoy tu emprendimiento dulce. ¡Cupos limitados!"
        ;;
    3)
        echo -e "${GREEN}\n[COPY SELECCIONADO: GANCHO]${NC}"
        echo "🎁 Tengo un regalo para ti: La guía rápida para [TEMA]."
        echo "Solo responde 'YO QUIERO' para enviártela."
        ;;
    *) exit ;;
esac
echo -e "\n${WHITE}Copia el texto y
presiona Enter para volver...${NC}"
read
