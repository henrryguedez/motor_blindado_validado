import sqlite3
from datetime import datetime
from pathlib import Path

HOME = Path.home()
DB_PATH = HOME / ".neovry_vcv.db"

# Contenidos optimizados para el Manual de Repostería
CONTENIDOS = {
    "VALOR": "¡Tip horno elite! Precalienta a 180°C para bizcochos perfectos siempre 🔥",
    "CONFIANZA": "Técnica de batido: Velocidad 3, 5 min, ingredientes a temperatura ambiente. ¡Esto cambia el resultado!",
    "VENTA": "¡Oferta elite activa! Curso Repostería Pro $47 → $27 por 24h ⏰ Link: https://tu-link.com",
}


def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS usuarios (
        id_usuario TEXT PRIMARY KEY,
        fase TEXT DEFAULT 'VALOR',
        score INTEGER DEFAULT 0,
        nombre TEXT,
        ultima_interaccion TEXT,
        comprado BOOLEAN DEFAULT FALSE
    )""")
    conn.commit()
    conn.close()


def ejecutar_flujo_vcv(id_usuario, mensaje_entrante="", nombre="Amigo"):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # 1. Asegurar registro del usuario
    c.execute(
        "INSERT OR IGNORE INTO usuarios (id_usuario, nombre) VALUES (?, ?)",
        (id_usuario, nombre),
    )
    c.execute("SELECT fase, score FROM usuarios WHERE id_usuario=?", (id_usuario,))
    fase_actual, score = c.fetchone()

    ahora = datetime.now().isoformat()
    msg_a_enviar = ""
    nueva_fase = fase_actual

    # 2. Lógica de detección de intención (Atajo)
    es_intencion_compra = any(
        p in mensaje_entrante.lower()
        for p in ["precio", "cuanto", "comprar", "costo", "valor"]
    )

    # --- FLUJO LÓGICO ---
    if es_intencion_compra and fase_actual != "VENTA":
        # Atajo directo a venta si pregunta precio
        msg_a_enviar = (
            f"¡Hola {nombre}! Veo que quieres ir directo al grano. "
            + CONTENIDOS["VENTA"]
        )
        nueva_fase = "VENTA"
        score += 6

    elif fase_actual == "VALOR":
        msg_a_enviar = f"¡Hola {nombre}! " + CONTENIDOS["VALOR"]
        nueva_fase = "CONFIANZA"
        score += 1

    elif fase_actual == "CONFIANZA":
        if es_intencion_compra:
            msg_a_enviar = "¡Excelente decisión! " + CONTENIDOS["VENTA"]
            nueva_fase = "VENTA"
            score += 5
        else:
            msg_a_enviar = CONTENIDOS["CONFIANZA"]
            nueva_fase = "VENTA"
            score += 2

    elif fase_actual == "VENTA":
        msg_a_enviar = CONTENIDOS["VENTA"]
        score += 1

    # 3. Simulación de envío (Aquí conectas tu bot de WA)
    if msg_a_enviar:
        print(f"\n[NEOVRY ELITE] Enviando a {id_usuario}:")
        print(f" > {msg_a_enviar}")

    # 4. Actualización persistente
    c.execute(
        "UPDATE usuarios SET fase=?, score=?, ultima_interaccion=? WHERE id_usuario=?",
        (nueva_fase, score, ahora, id_usuario),
    )
    conn.commit()
    conn.close()
