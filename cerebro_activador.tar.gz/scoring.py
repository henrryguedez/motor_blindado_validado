import json
import re


def calcular_score_neovry(mensaje_cliente):
    score = 0
    m = mensaje_cliente.lower()

    # Palabras de ALTA intención (Dinero/Acción)
    # Agregué "cuanto", "costo" y "pago"
    if any(
        p in m
        for p in [
            "pagar",
            "comprar",
            "link",
            "precio",
            "cuanto",
            "costo",
            "pago",
            "inscribirme",
        ]
    ):
        score += 75

    # Palabras de URGENCIA o CIERRE
    # Agregué "informacion" para dar un pequeño empujón
    if any(
        u in m
        for u in ["ahora", "ya", "mismo", "urgente", "hoy", "informacion", "info"]
    ):
        score += 25

    return score


def ejecutar_accion_comercial(mensaje_cliente, lead_id):
    score = calcular_score_neovry(mensaje_cliente)
    producto = buscar_producto_logico(mensaje_cliente)

    # Con el nuevo score, si pregunta "precio" + "info", ya suma 100
    if score >= 75 and producto:
        return f"🔥 VENTA DETECTADA: El cliente quiere comprar '{producto['nombre']}'. ENVIAR LINK: {producto['link']}"
    elif producto:
        return f"💡 INFO SOLICITADA: Enviando detalles de '{producto['nombre']}'..."

    return "❄️ LEAD FRÍO o PRODUCTO NO ENCONTRADO."
