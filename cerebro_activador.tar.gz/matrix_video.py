#!/usr/bin/env python3
print("""
🎥 MATRIX VIDEO GENERADO:

🔧 Tutorial Repuestos:
1. Levanta carro
2. Quita pieza vieja  
3. Instala nueva
4. Listo! 💰

[IMAGEN: carro_repuestos.png]
""")
