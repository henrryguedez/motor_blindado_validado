const { default: makeWASocket, useMultiFileAuthState, delay } = require("@whiskeysockets/baileys");
const pino = require("pino");
const qrcode = require("qrcode-terminal");

async function conectarBunker() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info');
    
    const sock = makeWASocket({
        auth: state,
        logger: pino({ level: "silent" }),
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, qr } = update;
        
        if (qr) {
            console.clear();
            console.log("👇 ESCANEA ESTE QR (TIENES 30 SEGUNDOS):");
            qrcode.generate(qr, { small: true });
            console.log("📡 Esperando escaneo...");
        }
        
        if (connection === 'close') {
            // Solo reintenta si no es un cierre voluntario
            setTimeout(() => conectarBunker(), 5000);
        } else if (connection === 'open') {
            console.clear();
            console.log("🚀 ¡VICTORIA! NEOVRY HUB CONECTADO.");
        }
    });
}
conectarBunker();
