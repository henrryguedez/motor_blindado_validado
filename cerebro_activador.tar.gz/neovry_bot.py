import telebot
import time

# Configuración del Token
TOKEN = '8464444106:AAEt-xpRQzVaImPhOh8lxI88pSDi556yPO8'
bot = telebot.TeleBot(TOKEN)

print("--- Neovry System: Telegram Channel Active ---")

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "🚀 Sistema Neovry Omnicanal Activo.\n¡Bienvenido, Henrry! El validador está listo.")

@bot.message_handler(commands=['activar'])
def handle_activar(message):
    bot.reply_to(message, "✅ Comando /activar recibido. Validando acceso desde Termux...")

@bot.message_handler(commands=['demo'])
def handle_demo(message):
    bot.reply_to(message, "🛠️ Iniciando modo Demo de Neovry Hub...")

@bot.message_handler(commands=['soporte'])
def handle_soporte(message):
    bot.reply_to(message, "📞 Contactando con soporte técnico de Neovry...")

# Bucle de reconexión automática
while True:
    try:
        print("Bot en línea...")
        bot.polling(none_stop=True, interval=0, timeout=20)
    except Exception as e:
        print(f"Error: {e}")
        time.sleep(5)
