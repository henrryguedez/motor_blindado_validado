#!/bin/bash
echo "Iniciando Infraestructura R22..."
ollama serve > /dev/null 2>&1 &
sleep 2
python3 neorvry.py
