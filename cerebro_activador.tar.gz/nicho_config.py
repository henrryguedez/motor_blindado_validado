# Configuración Maestra Neovry
CONFIG = {
    "PRODUCTO_ACTUAL": "REPOSTERIA",
    "REPOSTERIA": {
        "nombre": "Curso de Pastelería Pro",
        "link": "https://hotm.art/tu_link_reposteria",
        "keywords": ["torta", "precio", "pastel", "reposteria"],
    },
    "INGLES": {
        "nombre": "Inglés desde Cero",
        "link": "https://hotm.art/tu_link_ingles",
        "keywords": ["ingles", "clase", "aprender", "idioma"],
    },
}
