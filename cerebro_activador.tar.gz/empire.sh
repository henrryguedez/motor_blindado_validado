#!/data/data/com.termux/files/usr/bin/bash

while true; do
    clear
    echo -e "\033[0;36m╔══════════════════════════════════════╗"
    echo -e "║    ⚡ NEORVRY BUILDER EMPIRE | R22 ⚡ ║"
    echo -e "╚══════════════════════════════════════╝\033[0m"
    echo -e "1) CRM Pro (Ventas)   2) Copy Venta (Script)"
    echo -e "3) Lead Auto (Radar)  4) Ver Leads (Base)"
    echo "5) Salir"
    echo "======================================"
    read -p "➤ " opcion

    case $opcion in
        1) 
            # Llama a tu archivo de Python
            python crm_pro.py ;;
        2) 
            clear
            echo -e "\033[1;32m🚀 ESTRATEGIA DE ABORDAJE R22\033[0m"
            echo "--------------------------------------"
            echo -e "\033[1;37mCOPY SUGERIDO:\033[0m"
            echo "¡Hola! Vi tu perfil y el enfoque de tu marca"
            echo "encaja con nuestra metodología NEORVRY."
            echo "¿Estás abierto a escalar tu facturación?"
            echo "--------------------------------------"
            read -p "Presiona Enter para volver al menú..." ;;
        3) 
            clear
            echo -e "\033[1;34m🤖 LEAD AUTO: CAPTURA RÁPIDA\033[0m"
            echo "--------------------------------------"
            read -p "👤 Nombre del Prospecto: " p_nom
            read -p "📱 Instagram/WhatsApp: " p_con
            # Guardamos en la base de datos compartida
            echo "[$(date '+%d/%m')] | PROSPECTO: $p_nom | Link: $p_con" >> ventas.txt
            echo -e "\033[0;32m✅ Añadido al Radar de Seguimiento.\033[0m"
            sleep 2 ;;
        4) 
            clear
            echo -e "\033[0;36m--- 📋 BASE DE DATOS DE LEADS & VENTAS ---\033[0m"
            if [ -s ventas.txt ]; then
                cat -n ventas.txt
            else
                echo "Búnker vacío. Registra datos en la opción 1 o 3."
            fi
            echo "--------------------------------------"
            read -p "Presiona Enter para volver..." ;;
        5) 
            echo "Cerrando Búnker..."; exit 0 ;;
        *) 
            echo "Opción inválida"; sleep 1 ;;
    esac
done

