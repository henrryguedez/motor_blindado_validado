
import urllib.request
import json
from seguridad_pro import escudo_neovry

def consultar_gemini(pregunta):
    # Tu API KEY y URL deben estar definidas arriba en tu script principal
    cuerpo = {
        "contents": [
            {
                "parts": [
                    {
                        "text": f"Eres Chef Dulce, experto en repostería. Responde de forma vendedora: {pregunta}"
                    }
                ]
            }
        ]
    }
    
    req = urllib.request.Request(
        URL,
        data=json.dumps(cuerpo).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            res_data = json.loads(response.read().decode("utf-8"))
            respuesta_cruda = res_data["candidates"][0]["content"]["parts"][0]["text"]
            
            # --- AQUÍ SE ACTIVA EL ESCUDO DE SEGURIDAD ---
            # Pasamos la respuesta de la IA por el validador antes de retornarla
            respuesta_asegurada = escudo_neovry(respuesta_cruda)
            return respuesta_asegurada
            
    except Exception as e:
        return f"Error de conexión: {e}"

# --- PRUEBA DE SISTEMA ---
print("\n--- SINCRONIZACIÓN LITE NEOVRY ---")
resultado = consultar_gemini("Hola, ¿cómo hago para que mi pastel no se baje?")
print(f"Respuesta Protegida:\n{resultado}")

