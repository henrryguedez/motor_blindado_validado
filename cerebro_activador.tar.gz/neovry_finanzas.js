const capitalActual = 100;
const metaFinal = 1000000;

function calcularProgreso() {
    const porcentaje = (capitalActual / metaFinal) * 100;
    const faltante = metaFinal - capitalActual;
    
    console.log("\x1b[34m%s\x1b[0m", "--- DASHBOARD DE EXPANSIÓN NEOVRY ---");
    console.log("Capital Registrado: $" + capitalActual);
    console.log("Progreso hacia el Millón: " + porcentaje.toFixed(4) + "%");
    console.log("Faltante para la meta: $" + faltante.toLocaleString());
    
    if (porcentaje < 1) {
        console.log("\x1b[33m%s\x1b[0m", "Estado: Fase de Acumulación Inicial. Objetivo: Llegar al 2%.");
    }
}
calcularProgreso();
