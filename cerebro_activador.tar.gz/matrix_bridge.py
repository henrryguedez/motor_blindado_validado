import requests
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Importante para que Vercel pueda conectar


def consultar_llama(mensaje):
    # Esto habla con tu Llama 3.2 local
    url = "http://localhost:11434/api/generate"
    payload = {
        "model": "llama3.2",
        "prompt": f"Eres el sistema de ventas de Henrry. Sé persuasivo. Cliente dice: {mensaje}",
        "stream": False,
    }
    try:
        response = requests.post(url, json=payload)
        return response.json().get("response", "IA procesando...")
    except:
        return "Error: Asegúrate de que 'ollama serve' esté activo."


@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_msg = data.get("message", "")

    # El sistema procesa la respuesta de cierre
    respuesta_ia = consultar_llama(user_msg)

    # Notificación en tu consola de Termux
    print(f"\n[SISTEMA]: Nuevo mensaje del cliente: {user_msg}")

    return jsonify({"response": respuesta_ia})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
