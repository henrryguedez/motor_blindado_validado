# Lista de palabras clave para identificar alta intención
palabras_clave = ["precio", "inscripción", "costo", "valor", "cuanto"]

# Simulación de base de datos de Leads R22
leads_r22 = [
    "Hola, cuál es el precio del curso",
    "Quiero información sobre la inscripción",
    "Me interesa, pero cuál es el costo?",
    "Hola, buen día",
    "Podrías decirme el precio de la repostería",
    "Solo estoy mirando gracias",
]

# Filtrado de leads prioritarios (Python Puro)
leads_prioritarios = [
    lead
    for lead in leads_r22
    if any(palabra in lead.lower() for palabra in palabras_clave)
]

# Escritura de resultados en prioridad.txt
with open("prioridad.txt", "w", encoding="utf-8") as f:
    for lead in leads_prioritarios:
        f.write(f"{lead}\n")

print(f"[OK] Se han filtrado {len(leads_prioritarios)} leads a prioridad.txt")
