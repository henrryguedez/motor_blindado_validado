import shutil
import os
from datetime import datetime

# Configuración de colores
VERDE = "\033[92m"
AMARILLO = "\033[93m"
CYAN = "\033[96m"
FIN = "\033[0m"
NEGRITA = "\033[1m"

ARCHIVO_ORIGEN = "Sistema_Ventas_Neovry_V1.xlsx"
CARPETA_BACKUP = "backups"


def realizar_respaldo():
    try:
        # 1. Crear carpeta de backups si no existe
        if not os.path.exists(CARPETA_BACKUP):
            os.makedirs(CARPETA_BACKUP)
            print(f"{AMARILLO}[!] Carpeta '{CARPETA_BACKUP}' creada.{FIN}")

        # 2. Generar nombre con fecha y hora actual
        ahora = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        nombre_backup = f"Ventas_Backup_{ahora}.xlsx"
        ruta_destino = os.path.join(CARPETA_BACKUP, nombre_backup)

        # 3. Copiar el archivo
        if os.path.exists(ARCHIVO_ORIGEN):
            shutil.copy2(ARCHIVO_ORIGEN, ruta_destino)

            print(
                f"\n{VERDE}╔═════════════════════════════════════════════════════╗{FIN}"
            )
            print(
                f"{VERDE}║       🛡️  SISTEMA DE SEGURIDAD NEORVRY ACTIVADO      ║{FIN}"
            )
            print(
                f"{VERDE}╠═════════════════════════════════════════════════════╣{FIN}"
            )
            print(f"{VERDE}║{FIN} {NEGRITA}✅ RESPALDO EXITOSO:{FIN} {nombre_backup}  ")
            print(
                f"{VERDE}║{FIN} {NEGRITA}📂 UBICACIÓN:{FIN} /{CARPETA_BACKUP}                     "
            )
            print(
                f"{VERDE}╚═════════════════════════════════════════════════════╝{FIN}\n"
            )
        else:
            print(
                f"{AMARILLO}[!] Error: No se encontró el archivo original para respaldar.{FIN}"
            )

    except Exception as e:
        print(f"{AMARILLO}[!] Error en el proceso de seguridad: {e}{FIN}")


if __name__ == "__main__":
    realizar_respaldo()
