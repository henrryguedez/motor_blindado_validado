const { GoogleGenerativeAI } = require("@google/generative-ai");
require('dotenv').config();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Usamos el alias "gemini-flash-latest" que apareció en tu inspección
const model = genAI.getGenerativeModel({ model: "gemini-flash-latest" });

async function run() {
  try {
    const result = await model.generateContent("Hola Neovry, confirma conexión modo Elite.");
    console.log("\n\x1b[32m[SISTEMA OPERATIVO]:\x1b[0m");
    console.log(result.response.text());
  } catch (e) {
    console.log("\x1b[31m[ESTADO]:\x1b[0m", e.message);
    if (e.message.includes("429")) {
        console.log("Acción: La cuota de este modelo específico está en 0. Google activará el tráfico en unos minutos.");
    }
  }
}
run();
