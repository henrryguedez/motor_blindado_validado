// test_baileys.js
const { makeWASocket, useSingleFileAuthState } = require('@whiskeysockets/baileys');

function normalizeJid(numero) {
    numero = numero.replace(/s/g, '');
    if (!numero.startsWith('58') && numero.startsWith('4')) {
        numero = '58' + numero;
    }
    return numero + '@s.whatsapp.net';
}

const SESSION_FILE_PATH = './auth_info_baileys';

const { state, saveState } = useSingleFileAuthState(SESSION_FILE_PATH);

async function start() {
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true
    });

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            console.log('❌ Conexión cerrada. Reintentando...');
            start();
        } else if (connection === 'open') {
            console.log('✅ WhatsApp conectado!');
        }
    });

    sock.ev.on('creds.update', saveState);

    async function enviar(numero, mensaje) {
        const jid = normalizeJid(numero);
        console.log('📤 Enviando a:', jid);

        try {
            const result = await sock.sendMessage(jid, { text: mensaje });
            console.log('✅ Mensaje enviado:', result?.key?.id);
        } catch (e) {
            console.log('❌ Error al enviar:', e.message);
        }
    }

    // 1. Prueba con tu número
    // Cambia +58... por tu número real
    const miNumero = '+584141234567';  // 👈 TU NÚMERO
    enviar(miNumero, 'Prueba de Termux');

    // 2. Prueba con tu LEAD
    const lead = '584167443305';
    enviar(lead, 'Hola, ¿te interesa repostería?');

    return sock;
}

start();
