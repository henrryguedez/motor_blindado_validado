#!/usr/bin/env python3

filename = "prueba_leads.txt"

try:
    with open(filename, "r") as f:
        leads = f.readlines()

    print("Números de prueba:")
    for l in leads:
        numero = l.strip()
        if numero:
            print(numero)
except FileNotFoundError:
    print("❌ No existe prueba_leads.txt")
