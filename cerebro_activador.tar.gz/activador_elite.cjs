const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, delay } = require('@whiskeysockets/baileys');
const pino = require('pino');

async function iniciarBunker() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        auth: state,
        logger: pino({ level: 'silent' }),
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        syncFullHistory: false,
        markOnlineOnConnect: true
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (u) => {
        const { connection, lastDisconnect } = u;
        if (connection === 'open') {
            console.log("\n🛡️ SISTEMA ANTIBLOQUEO ACTIVO\n✅ ¡BUNKER ONLINE!");
        }
        if (connection === 'close') {
            // SI SE CIERRA, ESPERA 10 SEGUNDOS ANTES DE VOLVER A INTENTAR
            // ESTO AHORRA BATERÍA Y EVITA EL BUCLE
            console.log("🔄 Conexión inestable... Descansando 10s para ahorrar batería.");
            setTimeout(() => iniciarBunker(), 10000);
        }
    });

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message || msg.key.fromMe) return;

        const id = msg.key.remoteJid;
        const texto = (msg.message.conversation || msg.message.extendedTextMessage?.text || "").toLowerCase();
        const espera = Math.floor(Math.random() * (8000 - 4000 + 1)) + 4000;
        
        if (texto.includes('inglés') || texto.includes('ingles')) {
            await delay(espera); 
            await sock.sendMessage(id, { text: "¡Hola! 🚀 Aquí tienes tus 10 clases de Inglés gratis:\n\nhttps://sistema-unificado.vercel.app" });
        } 
        else if (texto.includes('repostería') || texto.includes('reposteria') || texto.includes('pastel')) {
            await delay(espera);
            await sock.sendMessage(id, { text: "¡Hola! 🍰 Aquí tienes los detalles de la Master Class de Repostería:\n\nhttps://go.hotmart.com/Q90190219S" });
        }
    });
}
iniciarBunker().catch(err => console.error(err));
