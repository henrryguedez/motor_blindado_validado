import sqlite3
import os


def registrar_prueba():
    ruta_db = os.path.expanduser("~/session_db/app_session.db")
    conexion = sqlite3.connect(ruta_db)
    cursor = conexion.cursor()

    # Datos de prueba para el Gran Arquitecto
    nombre = "Henrry"
    telefono = "584167443305"
    producto = "Neovry V10.0"

    try:
        cursor.execute(
            """
            INSERT INTO leads_captura (nombre, telefono, producto, estado_seguimiento)
            VALUES (?, ?, ?, ?)
        """,
            (nombre, telefono, producto, "ACTIVO"),
        )

        conexion.commit()
        print("\n\x1b[1;92m✅ REGISTRO EXITOSO EN EL BÚNKER\x1b[0m")
        print(f"👤 Nombre: {nombre}")
        print(f"📱 Teléfono: {telefono}")
        print(f"📦 Producto: {producto}")
    except sqlite3.IntegrityError:
        print("\n\x1b[1;93m⚠️ EL LEAD YA EXISTE EN LA BASE DE DATOS\x1b[0m")
    finally:
        conexion.close()


if __name__ == "__main__":
    registrar_prueba()
