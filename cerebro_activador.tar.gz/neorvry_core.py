import os, sys, subprocess

DB_DIR = os.path.expanduser("~/.neorvry_db")
os.makedirs(DB_DIR, exist_ok=True)
MEM_FILE = os.path.join(DB_DIR, "copiar_este.txt")


def guardar_en_memoria(query, respuesta):
    # Detección inteligente de nicho para el link
    link = (
        "👉 https://hotmart.com/tu-link-reposteria"
        if "postre" in query.lower() or "reposteria" in query.lower()
        else "👉 https://hotmart.com/tu-link-ingles"
    )
    with open(MEM_FILE, "w") as f:
        f.write(
            f"{respuesta}\n\n⚠️ ÚLTIMAS HORAS PARA EL DESCUENTO:\n{link}\n\n¡NO DEJES PASAR ESTA OPORTUNIDAD!"
        )


def ejecutar_ia(query):
    print("🧠 [SISTEMA NEORVRY R22] Generando Activo con Llama 3.2...")
    # Instrucción Maestra para que no divague
    prompt = f"Eres un experto en Copywriting de Respuesta Directa. Escribe UN solo anuncio potente, persuasivo y corto que ataque el dolor del cliente. No des opciones, solo el texto final. Orden: {query}"

    try:
        res = subprocess.run(
            ["ollama", "run", "llama3.2:1b", prompt], capture_output=True, text=True
        )
        output = (
            res.stdout.strip()
            if res.stdout.strip()
            else "Error: Sin respuesta de Llama."
        )
        guardar_en_memoria(query, output)
        return "✅ ¡ACTIVO DE ALTO IMPACTO GENERADO!"
    except Exception as e:
        return f"❌ Error en el motor: {e}"


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "ia":
        print(ejecutar_ia(sys.argv[2]))
    else:
        print("Uso: python neorvry_core.py ia 'orden de venta'")
