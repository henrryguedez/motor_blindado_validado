import os
import time
import datetime

# Cores Búnker
G, C, W, R, Y, N = '\033[92m', '\033[96m', '\033[97m', '\033[91m', '\033[93m', '\033[0m'

def clear(): os.system('clear')

def alianza_report():
    clear()
    print(f"{G}--- 🚀 REPORTE DE VENTAS - ALIANZA INDETENIBLE ---{N}")
    try:
        cliente = input(f"{W}Nombre del comprador: {N}")
        correo = input(f"{W}Correo del comprador: {N}")
        producto = input(f"{W}Producto: {N}")
        fecha_str = input(f"{W}Fecha (DD/MM/YYYY): {N}")
        v = datetime.datetime.strptime(fecha_str, "%d/%m/%Y")
        c = v + datetime.timedelta(days=17)
        msg = f"\n{G}✅ *SOLICITUD DE COMISIÓN*{N}\n{W}• Afiliado: Henrry Guedez\n• Producto: {producto}\n• Comprador: {cliente}\n• Correo: {correo}\n• Fecha: {fecha_str}\n{Y}📅 Cobro disponible: {c.strftime('%d/%m/%Y')}{N}\n"
        print(msg)
        with open("registro_comisiones.txt", "a") as f: f.write(msg)
        input(f"\n{C}[ENTER] para volver al HUB...{N}")
    except:
        print(f"\n{R}❌ Error en formato de fecha.{N}"); time.sleep(2)

def main():
    while True:
        clear()
        print(f"""
{G}     .---.        .-----------.{N}
{G}    /     \\      /  {W}NEOVRY HUB{G}  \\{N}
{G}   |  (0)  |    |  {C}V12.1 ONLINE{G}  |{N}
{G}    \\     /      \\  {Y}BUILD: 3D{G}   /{N}
{G}     '---'        '-----------'{N}
{W}╔══════════════════════════════════════╗{N}
{W} ║  {G}[🛰️] SISTEMA UNIFICADO DE VENTAS{W}    ║{N}
{W} ║  {C}ARQUITECTO: HENRRY GUEDEZ{W}          ║{N}
{W}╚══════════════════════════════════════╝{N}
 {Y}⚡ TARGET: $1,000,000{N} | {G}🌐 VERCEL: LIVE{N}
 {W}Leads: 02 | Score: 1.0 | Ping: 24ms{N}
 {W}──────────────────────────────────────{N}
 {C}CONFIANZA |{N} {G}██████████ 50%{N}
 {C}VENTAS    |{N} {G}███████████████ 80%{N}
{W}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{N}
 {G}1) CRM 3D           2) Artillería 12.1{N}
 {G}3) Seguimiento      4) Database Leads{N}
 {G}5) Info Búnker      7) Neural Bot{N}
 {G}8) Logs Encript.    {Y}9) Alianza Report{N}
 {R}6) Desconectar{N}
{W}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{N}""")
        
        op = input(f"{G}▶{C} NEOVRY{W} $ {N}")

        if op == "9":
            alianza_report()
        elif op == "6":
            print(f"\n{R}CERRANDO DIMENSIÓN... ADIÓS, ARQUITECTO.{N}"); break
        elif op in ["1","2","3","4","5","7","8"]:
            print(f"\n{Y}[!] Accediendo al módulo {op}...{N}"); time.sleep(1)
        else:
            print(f"\n{R}[!] Comando no reconocido.{N}"); time.sleep(1)

if __name__ == "__main__":
    main()

