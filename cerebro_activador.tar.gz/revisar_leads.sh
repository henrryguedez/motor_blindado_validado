#!/data/data/com.termux/files/usr/bin/bash
clear
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "   [SISTEMA R22+] FILTRANDO PROSPECTOS MAESTROS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
python filtro_r22.py
echo ""
echo "Leads con Alta Intención (Prioridad):"
echo "------------------------------------"
cat prioridad.txt
echo "------------------------------------"
echo "Presiona ENTER para volver al menú..."
read
