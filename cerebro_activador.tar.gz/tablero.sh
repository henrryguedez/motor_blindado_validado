#!/bin/bash
# TABLERO DE CONTROL - NEORVRY BUILDER

VENTAS_FILE="ventas.txt"
META=1000000

clear
echo -e "\e[1;33m================================================\e[0m"
echo -e "\e[1;32m       📊 TABLERO DE CONTROL ESTRATÉGICO       \e[0m"
echo -e "\e[1;33m================================================\e[0m"

if [ ! -f "$VENTAS_FILE" ]; then
    echo "Aún no hay datos de ventas registrados."
    exit
fi

# Calcular total (asumiendo formato: Fecha | Cliente | Monto)
TOTAL=$(awk -F'|' '{sum += $3} END {print sum}' "$VENTAS_FILE" | sed 's/ //g')

if [ -z "$TOTAL" ]; then TOTAL=0; fi

FALTANTE=$(echo "$META - $TOTAL" | bc)

echo -e "\e[1;37m DINERO RECAUDADO:  \e[1;32m$ $TOTAL\e[0m"
echo -e "\e[1;37m META FINAL:        \e[1;33m$ $META\e[0m"
echo -e "\e[1;37m FALTANTE:          \e[1;31m$ $FALTANTE\e[0m"
echo "------------------------------------------------"

# Pequeña barra de progreso visual
PORCENTAJE=$(echo "scale=2; ($TOTAL / $META) * 100" | bc)
echo -e "\e[1;37m PROGRESO: $PORCENTAJE %\e[0m"

echo "------------------------------------------------"
echo "Últimos movimientos:"
tail -n 5 "$VENTAS_FILE"
echo "------------------------------------------------"
read -p "Presiona Enter para volver..."
