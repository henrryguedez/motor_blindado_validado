import productos_hotmart

print(productos_hotmart.obtener_link(input("ID del producto: ")))
