import time
import os
import json

ARCHIVO_REGISTRO = 'registro_ventas.json'

def alertar():
    os.system('termux-vibrate -d 500')
    os.system('termux-tts-speak "Atencion Henrry, tienes un nuevo cliente en el sistema Neovry"')
    print('\n💰 [ALERTA] ¡CLIENTE DETECTADO! Revisa Vercel.')

def monitorear():
    print('🚀 SISTEMA NEORVRY: VIGILANCIA ACTIVA')
    # Inicializar el archivo si no existe
    if not os.path.exists(ARCHIVO_REGISTRO):
        with open(ARCHIVO_REGISTRO, 'w') as f: json.dump([], f)
    
    # Leer el estado inicial
    try:
        with open(ARCHIVO_REGISTRO, 'r') as f:
            ultima_cuenta = len(json.load(f))
    except:
        ultima_cuenta = 0
    
    while True:
        try:
            if os.path.exists(ARCHIVO_REGISTRO):
                with open(ARCHIVO_REGISTRO, 'r') as f:
                    datos = json.load(f)
                    actual_cuenta = len(datos)
                
                if actual_cuenta > ultima_cuenta:
                    alertar()
                    ultima_cuenta = actual_cuenta
                else:
                    # Esto confirma que estás en la versión nueva
                    print('👀 Escuchando Vercel... (Sin novedades)    ', end='\r')
            
        except Exception as e:
            pass
            
        time.sleep(5)

if __name__ == "__main__":
    monitorear()
