#!/bin/bash

# Colores Neovry
CYAN='\033[0;36m'
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
LOG_DIR="$HOME/logs"
mkdir -p "$LOG_DIR"

log() {
  echo "[$(date +%Y%m%d-%H:%M:%S)] $1" | tee -a "$LOG_DIR/neovry.log"
}

clear
log "${CYAN}=== DESPLIEGUE NEOVRY V10.0 - BARQUISIMETO HUB ===${NC}"

# 1. Limpieza de procesos previos para liberar el puerto 5000
pkill -f "python3 hotmart_webhook.py" 2>/dev/null
pkill -f "node vincular_whatsapp.js" 2>/dev/null
pkill -f "bore" 2>/dev/null

# 2. Webhook Hotmart (Receptor de Ventas)
log "Levantando Receptor de Ventas Python..."
python3 hotmart_webhook.py >> "$LOG_DIR/webhook.log" 2>&1 &
echo $! > "$LOG_DIR/webhook.pid"

# 3. Motor de Cierre VCV (Lógica de Ventas)
log "Activando Motor VCV Elite..."
python3 vcv_elite.py "SISTEMA" "ARRANQUE_OPERATIVO" >> "$LOG_DIR/ventas.log" 2>&1 &
echo $! > "$LOG_DIR/ventas.pid"

# 4. Puente de WhatsApp (Baileys)
if [ -f "vincular_whatsapp.js" ]; then
    log "Sincronizando WhatsApp Business..."
    node vincular_whatsapp.js >> "$LOG_DIR/wa.log" 2>&1 &
    echo $! > "$LOG_DIR/wa.pid"
fi

# 5. El Túnel (Vital para recibir datos de Hotmart)
if command -v bore >/dev/null 2>&1; then
    log "Abriendo Túnel Público..."
    bore local 5000 --to bore.pub >> "$LOG_DIR/tunnel.log" 2>&1 &
    echo $! > "$LOG_DIR/tunnel.pid"
else
    log "${RED}[!] Advertencia: 'bore' no instalado. El webhook no será público.${NC}"
fi

stop_all() {
  echo -e "\n${RED}[!] Apagando Bunker...${NC}"
  for pid in "$LOG_DIR"/*.pid; do
    [ -f "$pid" ] && kill $(cat "$pid") 2>/dev/null && rm "$pid"
  done
  log "Bunker Offline."
  exit 0
}

trap stop_all SIGINT

echo -e "${GREEN}✅ BUNKER NEOVRY OPERATIVO 24/7${NC}"
echo -e "${CYAN}Webhook (5000), VCV, WhatsApp y Túnel activos.${NC}"
echo -e "Presiona CTRL+C para detener todos los procesos."
tail -f "$LOG_DIR/neovry.log"

