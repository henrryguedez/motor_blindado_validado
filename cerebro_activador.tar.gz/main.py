#!/usr/bin/env python3
import json
import logging
from pathlib import Path
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, ContextTypes, CommandHandler, CallbackQueryHandler, MessageHandler, filters
)

# Configuración de registros
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

# --- CONFIGURACIÓN CRÍTICA ---
TOKEN = "8464444106:AAEt-xpRQzVaImPhOh8lxI88pSDi556yPO8" 
WA_PERSONAL = "https://wa.me/584167443305?text=¡Quiero%20comprar%20NEOVRY!"
DB_PATH = Path("neovry_users.json")

PRODUCTOS = {
    "reposteria": "🎂 Repostería Millonaria Pro: 500+ Recetas + IA Automatizada. $25 USD.",
    "ingles": "🇺🇸 Inglés Elite: Fluidez en 90 días con IA personalizada. $47 USD.",
    "ia": "🤖 Automatización IA: Bots + Funnels completos. $97 USD."
}

# --- FUNCIONES DE BASE DE DATOS ---
async def load_users():
    if DB_PATH.exists():
        try:
            with open(DB_PATH, "r") as f:
                return json.load(f)
        except: return {}
    return {}

async def save_users(users):
    with open(DB_PATH, "w") as f:
        json.dump(users, f, indent=4)

# --- MANEJADORES ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # Soporta tanto el comando /start como el botón de regreso
    user = update.effective_user
    user_id = str(user.id)
    
    users = await load_users()
    if user_id not in users:
        users[user_id] = {"nombre": user.first_name, "interes": None}
        await save_users(users)
    
    texto = f"¡Hola {user.first_name}! 💎 Bienvenido a NEOVRY Hub.\n\n¿Qué nicho quieres dominar?"
    keyboard = [
        [InlineKeyboardButton("🎂 Repostería", callback_data="reposteria")],
        [InlineKeyboardButton("🇺🇸 Inglés", callback_data="ingles")],
        [InlineKeyboardButton("🤖 IA & Bots", callback_data="ia")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    if update.message:
        await update.message.reply_text(texto, reply_markup=reply_markup)
    elif update.callback_query:
        await update.callback_query.edit_message_text(texto, reply_markup=reply_markup)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    
    if query.data == "start":
        await start(update, context)
        return

    user_id = str(query.from_user.id)
    users = await load_users()
    
    if query.data in PRODUCTOS:
        users[user_id]["interes"] = query.data
        await save_users(users)
        
        texto = f"¡Excelente elección! 👤\n\n{PRODUCTOS[query.data]}\n\n¿Listo para escalar?"
        keyboard = [
            [InlineKeyboardButton("💳 COMPRAR AHORA", callback_data=f"buy_{query.data}")],
            [InlineKeyboardButton("👤 Mi Perfil", callback_data="perfil")],
            [InlineKeyboardButton("🔄 Nuevo Producto", callback_data="start")]
        ]
        await query.edit_message_text(texto, reply_markup=InlineKeyboardMarkup(keyboard))

async def buy_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    
    user_id = str(query.from_user.id)
    users = await load_users()
    interes = users.get(user_id, {}).get("interes", "elite")
    
    await query.edit_message_text(
        f"🚀 ¡Cierre de oro!\n\nProducto: {interes.upper()}\n\n"
        f"Da clic para finalizar en WhatsApp:\n{WA_PERSONAL}",
        disable_web_page_preview=True
    )

async def perfil_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    
    user_id = str(query.from_user.id)
    users = await load_users()
    data = users.get(user_id, {})
    
    texto = (f"👤 **Tu Perfil NEOVRY**\n"
             f"Nombre: {data.get('nombre')}\n"
             f"Interés actual: {data.get('interes', 'Ninguno')}")
    
    keyboard = [[InlineKeyboardButton("⬅️ Volver", callback_data="start")]]
    await query.edit_message_text(texto, reply_markup=InlineKeyboardMarkup(keyboard))

async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    texto = update.message.text.lower()
    palabras = ['precio', 'costo', 'cuanto', 'comprar']
    if any(w in texto for w in palabras):
        await start(update, context)

def main() -> None:
    app = ApplicationBuilder().token(TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    # Filtro corregido para capturar todas las acciones de botones
    app.add_handler(CallbackQueryHandler(buy_handler, pattern="^buy_"))
    app.add_handler(CallbackQueryHandler(perfil_handler, pattern="^perfil$"))
    app.add_handler(CallbackQueryHandler(button_handler)) 
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))
    
    print("🛰️ SISTEMA NEOVRY ACTIVO")
    app.run_polling()

if __name__ == "__main__":
    main()

