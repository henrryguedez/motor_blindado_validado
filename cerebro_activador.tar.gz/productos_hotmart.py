def obtener_link(producto):
    links = {
        "reposteria": "https://hotm.art/tu_link_reposteria",
        "jabones": "https://hotm.art/tu_link_jabones",
        "sushi": "https://hotm.art/tu_link_sushi",
        "ingles": "https://hotm.art/tu_link_ingles",
        "cejas": "https://hotm.art/tu_link_cejas",
    }
    return links.get(producto, "Pronto te daremos más información.")
