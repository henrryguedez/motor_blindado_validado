import telebot
import json
import os
import time

# 🔑 CONFIGURACIÓN
TOKEN = "8658877853:AAE9MDxujiGgwdvYwNY0BFVmmYNyiPF2U20"
bot = telebot.TeleBot(TOKEN)
DB_FILE = 'neovry_users.json'
ADMIN_ID = 6951875143
FOTO_ID = "AgACAgEAAxkBAANuafv2UTkQOYPZROJMP8uIoz_AxlIAAiMMaxvzNuBHxoIgOjP5QpwBAAMCAAN3AAM7BA"

# --- DIFUSIÓN ---
def ejecutar_difusion(plantilla):
    if not os.path.exists(DB_FILE): return
    with open(DB_FILE, 'r') as f: usuarios = json.load(f)
    exitos = 0
    for uid, datos in usuarios.items():
        try:
            nombre = datos.get('nombre', 'Emprendedor')
            bot.send_photo(uid, FOTO_ID, caption=plantilla.replace("{nombre}", nombre))
            exitos += 1
            time.sleep(1)
        except: pass
    bot.send_message(ADMIN_ID, f"✅ Difusión: {exitos} enviados.")

# --- COMANDOS ---
@bot.message_handler(commands=['difundir'])
def iniciar_difundir(message):
    if message.from_user.id != ADMIN_ID: return
    partes = message.text.split(maxsplit=1)
    if len(partes) < 2: return
    markup = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True).add('🚀 CONFIRMAR', '❌ CANCELAR')
    msg = bot.send_message(ADMIN_ID, f"📝 ¿Enviar esto?\n\n{partes[1]}", reply_markup=markup)
    bot.register_next_step_handler(msg, lambda m: ejecutar_difusion(partes[1]) if m.text == '🚀 CONFIRMAR' else bot.send_message(ADMIN_ID, "❌ Cancelado"))

# --- MENÚ INTERACTIVO (LEE TU PERFIL AUTOMÁTICAMENTE) ---
@bot.message_handler(func=lambda message: True)
def responder_siempre(message):
    markup = telebot.types.InlineKeyboardMarkup(row_width=1)
    
    # Botones informativos
    btn1 = telebot.types.InlineKeyboardButton("📦 Nuestros Servicios", callback_data="servicios")
    btn2 = telebot.types.InlineKeyboardButton("🔥 Ver Promociones", callback_data="promos")
    
    # 🔗 ENLACE DINÁMICO: Te busca por tu ID para que nunca falle el contacto
    btn3 = telebot.types.InlineKeyboardButton("👨‍💻 Hablar con Henrry", url=f"tg://user?id={ADMIN_ID}")
    
    markup.add(btn1, btn2, btn3)
    bot.send_message(message.chat.id, "¡Hola! Bienvenido a **NEOVRY**. ¿Cómo podemos ayudarte hoy?", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: True)
def callback_respuestas(call):
    respuestas = {
        "servicios": "✅ Ofrecemos: Difusiones masivas, creación de bots y automatización.",
        "promos": "🎁 ¡Consulta nuestras ofertas especiales contactando al administrador!"
    }
    if call.data in respuestas:
        bot.send_message(call.message.chat.id, respuestas[call.data])
    bot.answer_callback_query(call.id)

print("🚀 NEOVRY ONLINE - BOTÓN INTELIGENTE ACTIVO")
bot.infinity_polling()

