import requests
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)


@app.route("/chat", methods=["GET", "POST"])
def chat():
    if request.method == "GET":
        return "SISTEMA ACTIVO: El servidor está listo para recibir mensajes de Vercel."

    data = request.json
    user_input = data.get("message", "")
    print(f"\n[CLIENTE]: {user_input}")

    # Conexión con Ollama
    try:
        r = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": "llama3.2", "prompt": user_input, "stream": False},
            timeout=15,
        )
        respuesta = r.json().get("response", "IA sin respuesta.")
    except:
        respuesta = "Error: Enciende 'ollama serve' en otra pestaña."

    return jsonify({"response": respuesta})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
