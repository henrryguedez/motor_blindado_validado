const http = require('http');
const { exec } = require('child_process');

// Tu función blindada integrada
function responderYenviarAlWhatsApp(iaResponse, clientePhone, logger = console.log) {
  const limpiaTexto = String(iaResponse || "")
    .trim()
    .replace(/\n+/g, " ")
    .replace(/ {2,}/g, " ")
    .replace(/"/g, '\\"')
    .replace(/\\/g, '\\\\');

  logger(`🤖 [IA RESPONDE]:\n${limpiaTexto}`);

  const scriptCmd = `node enviar_wa.cjs "${clientePhone}" "${limpiaTexto}"`;
  exec(scriptCmd, (error, stdout, stderr) => {
    if (error) {
      logger(`❌ Error al enviar WA: ${error?.message || error}`);
      return;
    }
    logger(`✅ WhatsApp enviado OK: ${clientePhone}`);
  });
}

const server = http.createServer((req, res) => {
    if (req.method === 'POST' && req.url === '/webhook') {
        let body = '';
        req.on('data', chunk => { body += chunk.toString(); });
        req.on('end', () => {
            try {
                const data = JSON.parse(body);
                console.log(`\n📩 [L99] Lead Recibido: ${data.name} (${data.phone})`);

                exec(`python3 neovry_v9.py "${data.phone}" "${data.product}"`, (error, stdout) => {
                    if (error) {
                        console.error(`❌ [Error IA]: ${error.message}`);
                        return;
                    }
                    responderYenviarAlWhatsApp(stdout, data.phone);
                });

                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ status: 'Procesando' }));
            } catch (e) {
                res.writeHead(400);
                res.end();
            }
        });
    }
});

server.listen(3010, () => {
    console.log('🚀 [L99] HUB SINCRONIZADO EN PUERTO 3010');
});
