import re


def extraer_numero(texto):
    # Busca una secuencia de 10 a 13 dígitos (formato internacional)
    match = re.search(r"\d{10,13}", texto)
    return match.group(0) if match else None


with open("leads_recientes.txt", "r") as f:
    lineas = f.readlines()

leads_limpios = []
for linea in lineas:
    num = extraer_numero(linea)
    if num:
        leads_limpios.append(num)

with open("leads_limpios.txt", "w") as f:
    for lead in leads_limpios:
        f.write(lead + "\n")

print(f"✅ Se limpiaron {len(leads_limpios)} leads. Listos en leads_limpios.txt")
