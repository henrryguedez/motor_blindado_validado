const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const { exec } = require('child_process');
const path = require('path');

const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: {
        executablePath: '/data/data/com.termux/files/usr/bin/chromium',
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    }
});

client.on('qr', qr => {
    console.log('🛡️ ESCANEA ESTE CÓDIGO PARA ACTIVAR EL OÍDO:');
    qrcode.generate(qr, {small: true});
});

client.on('ready', () => {
    console.log('🚀 NEOVRY HUB: El sistema está escuchando...');
});

client.on('message', async msg => {
    const texto = msg.body.toLowerCase();
    const nombre = msg._data.notifyName || "Cliente";

    let nicho = "";
    if (texto.includes("jabones")) nicho = "jabones";
    if (texto.includes("resina")) nicho = "resina";
    if (texto.includes("reposteria")) nicho = "reposteria";

    if (nicho !== "") {
        console.log(`🎯 Gatillo detectado: ${nombre} quiere ${nicho}`);
        
        exec(`bash vender.sh "${nombre}" "${nicho}"`, async (error) => {
            if (error) return console.error(`❌ Error: ${error.message}`);
            
            const videoPath = path.join(__dirname, 'assets', `video_${nombre}.mp4`);
            try {
                const media = MessageMedia.fromFilePath(videoPath);
                await client.sendMessage(msg.from, media, { 
                    caption: `Hola ${nombre}, aquí tienes la oferta de ${nicho} que pediste. 🚀` 
                });
                console.log(`✅ Respuesta enviada a ${nombre}`);
            } catch (err) {
                console.error("❌ Error al enviar archivo:", err);
            }
        });
    }
});

client.initialize();
