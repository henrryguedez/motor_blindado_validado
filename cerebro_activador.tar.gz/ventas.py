import datetime
import os
import json


def limpiar_pantalla():
    os.system("cls" if os.name == "nt" else "clear")


def gestionar_config(campo, valor=None):
    archivo_config = "config.json"
    config = {"meta": 0.0, "usuario": "Usuario", "turno": "No asignado"}
    if os.path.exists(archivo_config):
        try:
            with open(archivo_config, "r") as f:
                config.update(json.load(f))
        except:
            pass
    if valor is not None:
        config[campo] = valor
        with open(archivo_config, "w") as f:
            json.dump(config, f, indent=4)
        return valor
    return config.get(campo)


def registrar_venta_csv(precio):
    archivo = "ventas.csv"
    ahora = datetime.datetime.now()
    fecha = ahora.strftime("%d/%m/%Y")
    hora = ahora.strftime("%H:%M:%S")
    neto = precio * 0.9
    existe = os.path.exists(archivo)
    with open(archivo, "a") as f:
        if not existe:
            f.write("Fecha,Hora,Precio,Neto\n")
        f.write(f"{fecha},{hora},{precio},{neto}\n")
    print(f"\n✅ Venta de ${precio} guardada en Excel (CSV)")


def mostrar_tablero(usuario, meta, turno):
    while True:
        limpiar_pantalla()
        print("=" * 45)
        print(f"    💎  {turno.upper()}: {usuario.upper()}  💎")
        print("=" * 45)
        print(f" 🎯 META ACTUAL: $ {meta}")
        print("=" * 45)
        print(" 1. ➕ Registrar Venta")
        print(" 2. 🚪 Salir")
        print("=" * 45)
        opc = input("Selecciona una opción: ")
        if opc == "1":
            try:
                monto = float(input("\n💰 Monto de la venta: "))
                registrar_venta_csv(monto)
                input("\nPresiona Enter para continuar...")
            except:
                print("❌ Monto inválido")
                input()
        elif opc == "2":
            break


if __name__ == "__main__":
    if input("🔒 Clave: ") == "11880788":
        user = gestionar_config("usuario")
        if user == "Usuario":
            user = gestionar_config("usuario", input("👤 ¿Nombre?: "))
        goal = gestionar_config("meta")
        if goal == 0.0:
            goal = gestionar_config("meta", float(input("🎯 Meta: ")))
        turn = gestionar_config("turno")
        if turn == "No asignado":
            turn = gestionar_config("turno", input("⏰ ¿Turno?: "))
        mostrar_tablero(user, goal, turn)
