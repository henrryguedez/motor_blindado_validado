module.exports = {
    leerEnviosHoy: () => 0,
    registrarEnvio: (num) => console.log('Registrado:', num),
    puedeEnviarHoy: () => true
};
