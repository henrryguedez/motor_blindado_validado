import productos_hotmart as boveda


def simular_chat():
    print("\n" + "=" * 40)
    print("🤖 NEORVRY BUILDER - MODO PRUEBA")
    print("=" * 40)

    # Simulación de mensajes de clientes
    mensajes_prueba = [
        "Hola, me interesa el curso de reposteria",
        "Quiero info sobre los jabones artesanales",
        "¿Tienen algo de sushi?",
        "Me interesa aprender ingles",
        "¿Como funciona lo de las cejas?",
    ]

    for mensaje in mensajes_prueba:
        print(f"\n👤 Cliente dice: '{mensaje}'")

        # Lógica de detección simple (la que usa tu sistema)
        encontrado = False
        for clave in boveda.PRODUCTOS.keys():
            # Limpiamos el nombre interno para buscarlo en el mensaje
            busqueda = clave.replace("_", " ")
            if busqueda.split()[0] in mensaje.lower():
                link = boveda.obtener_link(clave)
                print(
                    f"✅ Neorvry responde: '¡Claro! Aquí tienes la información: {link}'"
                )
                encontrado = True
                break

        if not encontrado:
            print(
                "⚠️ Neorvry responde: 'Lo siento, no encontré ese producto en mi base de datos.'"
            )

    print("\n" + "=" * 40)


if __name__ == "__main__":
    simular_chat()
