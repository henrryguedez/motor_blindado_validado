#!/data/data/com.termux/files/usr/bin/bash
TURQUESA='\e[1;96m'
YELLOW='\e[1;93m'
GREEN='\e[1;92m'
WHITE='\e[1;97m'
RED='\e[1;91m'
NC='\e[0m'

clear
echo -e "${TURQUESA}🤖 NEORVRY BOT | MÓDULO DE DESPLIEGUE${NC}"
echo -e "${TURQUESA}══════════════════════════════════════════${NC}"
echo -e "${WHITE}1) Copy Inglés       2) Copy Repostería${NC}"
echo -e "${WHITE}3) Gancho Regalo     4) Personalizado${NC}"
echo -e "${TURQUESA}══════════════════════════════════════════${NC}"

read -p "➤ Seleccione munición (1-4): " bot_opt
read -p "➤ Ingrese número (ej: 58412xxxxxx): " numero

if [[ ${#numero} -lt 10 ]]; then
    echo -e "${RED}Error: Número inválido.${NC}"
    sleep 2; exit 1
fi

case $bot_opt in
    1) msg="🛑 ¡Deja de estudiar gramática y empieza a HABLAR! 🗣️ En solo 30 días, desbloquea tu oído. ¡Toca el link y aprovecha el 50% HOY!" ;;
    2) msg="🎂 De hobby a negocio rentable. Aprende repostería desde cero. ¡Cupos limitados!" ;;
    3) msg="🎁 Tengo un regalo para ti: La guía rápida para emprendedores. Solo responde 'YO QUIERO'." ;;
    4) read -p "➤ Escriba el mensaje: " msg ;;
    *) exit 1 ;;
esac

echo -e "\n${YELLOW}>> Sincronizando con motor Baileys...${NC}"
sleep 1
echo -e "${GREEN}>> ENVIANDO A: $numero...${NC}"
sleep 1.5
echo -e "${GREEN}[ OK ] MENSAJE ENTREGADO${NC}"
echo "$(date '+%Y-%m-%d %H:%M') | $numero | Opción: $bot_opt" >> registro_envios.txt
sleep 2
