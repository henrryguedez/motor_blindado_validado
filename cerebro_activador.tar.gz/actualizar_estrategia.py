import json
import os

nueva_estrategia = {
    "protocolo": "Activador Elite v2.0",
    "filtros": ["Gancho Emocional", "Validación de Interés", "Cierre por WhatsApp"],
    "mensajes_clave": {
        "bienvenida": "¡Hola! He activado el radar para tu solicitud. Estás a un paso de entrar al sistema.",
        "cierre": "La Alianza Indetenible ya está operando. ¿Confirmas tu acceso para iniciar la configuración?",
        "seguimiento": "El sistema detecta una oportunidad pendiente. ¿Deseas que terminemos el proceso ahora?",
    },
    "objetivo_valor": "Filtro de Alto Valor (Escalamiento 2026)",
}


def integrar_conocimiento():
    archivo_mensajes = "mensajes_vcv.json"
    if os.path.exists(archivo_mensajes):
        with open(archivo_mensajes, "r", encoding="utf-8") as f:
            try:
                datos = json.load(f)
            except:
                datos = {}
        datos.update({"estrategia_drive_2026": nueva_estrategia})
        with open(archivo_mensajes, "w", encoding="utf-8") as f:
            json.dump(datos, f, indent=4, ensure_ascii=False)
        print("✅ Estrategia integrada en mensajes_vcv.json")
    else:
        with open(archivo_mensajes, "w", encoding="utf-8") as f:
            json.dump(nueva_estrategia, f, indent=4, ensure_ascii=False)
        print("✅ Archivo mensajes_vcv.json creado con éxito.")


if __name__ == "__main__":
    integrar_conocimiento()
