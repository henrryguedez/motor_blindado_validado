const { default: makeWASocket, useMultiFileAuthState } = require("@whiskeysockets/baileys");
const pino = require("pino");

// Protocolo L99: Seguridad de Proceso
const TIMEOUT_MS = 15000;
const timeout = setTimeout(() => {
    console.error("[L99-ERROR] Timeout: La conexión de WhatsApp tardó demasiado.");
    process.exit(1);
}, TIMEOUT_MS);

async function enverL99(numero, mensaje) {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    const sock = makeWASocket({
        auth: state,
        logger: pino({ level: "silent" })
    });

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('connection.update', async (update) => {
        const { connection } = update;
        if (connection === 'open') {
            clearTimeout(timeout);
            const jid = `${numero.replace(/[^0-9]/g, '')}@s.whatsapp.net`;
            await sock.sendMessage(jid, { text: mensaje });
            console.log(`[L99-SUCCESS] Enviado a ${numero}`);
            setTimeout(() => process.exit(0), 1000);
        }
    });
}

const [,, num, msg] = process.argv;
if (num && msg) {
    enverL99(num, msg);
} else {
    console.log("Uso: node enver_pro.cjs <numero> <mensaje>");
    process.exit(1);
}
