import os
import sys


def clear():
    os.system("clear")


def menu():
    while True:
        clear()
        print("\033[1;35m========================================")
        print("       NEORVRY EMPIRE - R22 PRO         ")
        print("========================================\033[0m")
        print(" 💰 CAPITAL ACTUAL : $ 1,000.00 USD")
        print(" 📈 PROGRESO       : [▓░░░░░░░░░░░░░░░░░░░] 0.1%")
        print(" 🌐 STATUS API     : ONLINE (Live Data)")
        print("\033[1;35m========================================\033[0m")
        print("\n 1) 🚀 CRM PRO (Registrar Ventas)")
        print(" 2) 🤖 AUTO-CLOSER (Cerrador Automático)")
        print(" 3) 📡 LEAD RADAR (Captura de Leads)")
        print(" 4) 📊 TABLERO DE CONTROL")
        print(" 5) ❌ SALIR")

        try:
            opcion = input("\n\033[1;32m➤ SELECCIÓN: \033[0m")
            if opcion == "1":
                os.system("python crm_pro.py")
            elif opcion == "2":
                os.system("python auto_closer.py")
            elif opcion == "3":
                os.system("bash copys.sh")
            elif opcion == "4":
                os.system("bash tablero.sh")
            elif opcion == "5":
                print("\nCerrando Imperio...")
                break
        except EOFError:
            break  # Evita que el sistema explote si hay error de lectura
        except KeyboardInterrupt:
            break


if __name__ == "__main__":
    menu()
