import sqlite3
import pandas as pd
from pathlib import Path
from datetime import datetime, timedelta

HOME = Path.home()
DB_PATH = HOME / ".neovry_vcv.db"


def consultas_metricas_avanzadas():
    if not DB_PATH.exists():
        print("❌ Esperando primer lead...")
        return

    conn = sqlite3.connect(DB_PATH)
    # Leemos la tabla con los nombres reales de la V3.0
    df = pd.read_sql_query("SELECT * FROM usuarios", conn)
    total_usuarios = len(df)

    if total_usuarios == 0:
        print("📊 Sistema listo. Esperando tráfico...")
        return

    # Cálculos usando los nombres nuevos
    ayer = (datetime.now() - timedelta(hours=24)).isoformat()
    activos_24h = len(df[df["ultima_interaccion"] > ayer])
    score_alto = len(df[df["score"] >= 5])

    print("\n" + "🚀" * 15)
    print("  MÉTRICAS V.C.V - NEOVRY 2026")
    print("🚀" * 15)
    print(f"📊 Total Leads: {total_usuarios:>4} | 🔥 Activos 24h: {activos_24h:>4}")
    print(f"💎 Score Alto:  {score_alto:>4}")
    print("-" * 35)

    fases = (
        df.groupby("fase")
        .agg(cantidad=("id_usuario", "count"), score_avg=("score", "mean"))
        .reset_index()
    )

    for _, row in fases.iterrows():
        porcentaje = (row["cantidad"] / total_usuarios) * 100
        barra = "█" * int(porcentaje // 10)
        print(
            f" {row['fase']:>10} | {barra:<10} {int(row['cantidad']):>3} ({porcentaje:>4.1f}%) | Score: {row['score_avg']:.1f}"
        )

    print("-" * 35)
    if score_alto == 0:
        print("⚠️ ALERTA: Sin leads calientes aún.")
    conn.close()


if __name__ == "__main__":
    consultas_metricas_avanzadas()
