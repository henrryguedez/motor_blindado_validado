import sqlite3
import os


def mostrar_leads():
    ruta_db = os.path.expanduser("~/session_db/app_session.db")
    conexion = sqlite3.connect(ruta_db)
    cursor = conexion.cursor()

    print("\n\x1b[1;94m==== [ AUDITORÍA DE LEADS - NEOVRY V10.0 ] ====\x1b[0m")
    cursor.execute(
        "SELECT id, nombre, telefono, producto, estado_seguimiento FROM leads_captura"
    )
    rows = cursor.fetchall()

    if not rows:
        print("El búnker está vacío.")
    else:
        for row in rows:
            print(
                f"ID: {row[0]} | 👤 {row[1]} | 📱 {row[2]} | 📦 {row[3]} | 🚩 {row[4]}"
            )

    print("\x1b[1;94m===============================================\x1b[0m\n")
    conexion.close()


if __name__ == "__main__":
    mostrar_leads()
