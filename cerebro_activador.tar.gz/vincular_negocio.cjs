const { default: makeWASocket, useMultiFileAuthState, delay } = require('@whiskeysockets/baileys');
const pino = require('pino');

async function auth() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    const sock = makeWASocket({ 
        auth: state, 
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        browser: ["Mac OS", "Safari", "15.1"] 
    });

    sock.ev.on('creds.update', saveCreds);

    console.log('📡 Sincronizando Búnker con WhatsApp Business...');
    await delay(7000); 

    if (!sock.authState.creds.registered) {
        try {
            const numero = "584167443305";
            const code = await sock.requestPairingCode(numero);
            console.log('\n\x1b[1;32m======================================');
            console.log('TU CÓDIGO DE VINCULACIÓN ES:', code);
            console.log('======================================\x1b[0m\n');
        } catch (err) {
            console.log('\n\x1b[1;31m[!] El servidor sigue en espera. No desesperes, Henrry. Intentemos en un rato o con QR.\x1b[0m');
            process.exit(1);
        }
    }

    sock.ev.on('connection.update', (update) => {
        if (update.connection === 'open') {
            console.log('🚀 ¡BÚNKER VINCULADO EXITOSAMENTE!');
            process.exit(0);
        }
    });
}
auth();
