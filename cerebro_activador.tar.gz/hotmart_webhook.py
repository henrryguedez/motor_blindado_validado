#!/usr/bin/env python3
import os
import json
import subprocess
from flask import Flask, request

app = Flask(__name__)

# CONFIGURACIÓN DEL BUNKER
LOG_UNIFICADO = "neovry_pro_ventas.log"
SCRIPT_ENVIO = "node enviar_L99.js"


@app.route("/hotmart", methods=["POST"])
def hotmart_venta():
    try:
        data = request.json
        if not data:
            return "No Data", 400

        status = data.get("status", "APPROVED")
        email = data.get("data", {}).get("buyer", {}).get("email", "N/A")
        phone = data.get("data", {}).get("buyer", {}).get("checkout_phone", "")
        product = data.get("data", {}).get("product", {}).get("name", "Producto Neovry")
        price = (
            data.get("data", {})
            .get("purchase", {})
            .get("full_price", {})
            .get("value", 0)
        )

        log_entry = f"FECHA: 2026-04-29 | PRODUCTO: {product} | CLIENTE: {email} | MONTO: ${price} | STATUS: {status}\n"
        with open(LOG_UNIFICADO, "a") as f:
            f.write(log_entry)

        if status == "APPROVED" and phone:
            print(f"🚀 Disparando entrega para {phone}...")
            subprocess.Popen(
                [
                    f"{SCRIPT_ENVIO} {phone} '¡Gracias por tu compra! Ya tienes acceso a {product}.'"
                ],
                shell=True,
            )

        print(f"✅ Procesado: {email} - ${price}")
        return "SUCCESS", 200

    except Exception as e:
        with open("error_webhook.log", "a") as ef:
            ef.write(f"ERROR: {str(e)}\n")
        return "ERROR", 500


if __name__ == "__main__":
    print("🛡️ NEOVRY WEBHOOK ACTIVO - ESCUCHANDO HOTMART...")
    app.run(host="0.0.0.0", port=5000)
