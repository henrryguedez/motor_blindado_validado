import telebot

# Usando el nuevo token que obtuviste de BotFather
TOKEN = "8658877853:AAE9MDxujiGgwdvYwNY0BFVmmYNyiPF2U20"
bot = telebot.TeleBot(TOKEN)

try:
    me = bot.get_me()
    print(f"✅ ¡Conexión exitosa! El bot se llama: @{me.username}")
except Exception as e:
    print(f"❌ Error de conexión: {e}")

