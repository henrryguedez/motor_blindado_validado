# --- Configuración de nichos (fácil de expandir) ---
NICHES = {
    "NICHO_REPOSTERIA": {
        "keywords_fuente": ["reposteria", "pastel", "postre", "cupcake", "cakes", "bakery"],
        "keywords_mensaje": ["repostería", "pastel", "postre", "cupcake", "cake", "pastelero", "dulce"],
        "prompt": (
            "Eres un experto pastelero y docente de repostería. "
            "Saluda con calidez y haz sentir especial al prospecto. "
            "Ofrece de forma clara y ordenada el catálogo de cursos de repostería, "
            "resaltando resultados y beneficios para alguien que quiere aprender a hornear en casa."
        ),
    },
    "NICHO_INGLES": {
        "keywords_fuente": ["ingles", "english", "idioma", "aprender ingles", "learn english"],
        "keywords_mensaje": ["inglés", "english", "idioma", "aprender ingles", "learn english", "bilingue"],
        "prompt": (
            "You are an empathetic English coach for Spanish‑speakers. "
            "First, recognize the importance of being bilingual in 2026. "
            "Then, introduce your course in a clear and friendly way, "
            "highlighting quick results, practical methods, and real‑life usage."
        ),
    },
}

DEFAULT_NICHE = "GENERAL"
DEFAULT_PROMPT = (
    "Eres un asesor amable y orientado a resultados. "
    "Responde al mensaje de forma cordial y profesional, "
    "y pregunta de forma sencilla sobre qué área le interesa para poder ayudarle mejor."
)


# --- Función central de clasificación mejorada ---
def clasificar_lead(mensaje_entrante: str, fuente_url: str) -> str:
    """
    Clasifica el lead según URL y mensaje entrante.
    Prioriza: 1) URL, 2) mensaje, 3) nicho general.
    """
    # Normalizar texto
    msg_lower = mensaje_entrante.lower() if mensaje_entrante else ""
    url_lower = fuente_url.lower() if fuente_url else ""

    # Buscar por URL primero
    for niche, config in NICHES.items():
        # Comprobar si alguna palabra clave está en la URL
        if any(kw in url_lower for kw in config["keywords_fuente"]):
            return niche

    # Si no matcheó por URL, buscar en el mensaje
    for niche, config in NICHES.items():
        if any(kw in msg_lower for kw in config["keywords_mensaje"]):
            return niche

    # Si no coincide con nada, nicho general
    return DEFAULT_NICHE


# --- Obtener el prompt adecuado para TinyLlama ---
def obtener_prompt_para_tinyllama(nicho: str) -> str:
    return NICHES.get(nicho, {}).get("prompt", DEFAULT_PROMPT)


# --- Ejemplo de uso en tu bunker (integración con TinyLlama) ---
def preparar_prompt_tinyllama(mensaje_entrante: str, fuente_url: str) -> str:
    nicho = clasificar_lead(mensaje_entrante, fuente_url)
    pre_prompt = obtener_prompt_para_tinyllama(nicho)

    # Puedes agregar aquí el contexto del mensaje del cliente
    final_prompt = f"{pre_prompt}

Mensaje del prospecto: "{mensaje_entrante}""
    return final_prompt


# --- Ejemplos de prueba ---
if __name__ == "__main__":
    print(clasificar_lead("Quiero un curso de repostería", "sitio.com/reposteria"))  # NICHO_REPOSTERIA
    print(clasificar_lead("How can I join the English course?", "sitio.com/ingles"))  # NICHO_INGLES
    print(clasificar_lead("Hola, ¿qué ofreces?", "sitio.com/facebook"))             # GENERAL
    print(preparar_prompt_tinyllama("Dime qué cursos tienes", "sitio.com/reposteria"))
final_prompt = f"{pre_prompt}\n\nMensaje del prospecto: '{mensaje_entrante}'\nResponde de forma breve y persuasiva."

