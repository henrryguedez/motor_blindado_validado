#!/bin/bash
# Este script une el Hub con la IA y el Envío
NUMERO=$1
MENSAJE=$2

# 1. La IA genera la respuesta
RESPUESTA=$(python3 neovry_v9.py "$NUMERO" "$MENSAJE" | tail -n 5)

# 2. El Inyector envía a WhatsApp
node enver_pro.cjs "$NUMERO" "$RESPUESTA"
