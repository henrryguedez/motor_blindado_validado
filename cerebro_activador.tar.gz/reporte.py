import pandas as pd

# Colores y Estilo
VERDE, AZUL, AMARILLO, CYAN = "\033[92m", "\033[94m", "\033[93m", "\033[96m"
FIN, NEGRITA = "\033[0m", "\033[1m"

ARCHIVO = "Sistema_Ventas_Neovry_V1.xlsx"
META_FINAL = 1000000.00


def ejecutar_reporte():
    try:
        df = pd.read_excel(ARCHIVO, sheet_name="Registro de Ventas")
        total_acumulado = df["Comisión Recibida ($)"].sum()

        # --- NUEVA LÓGICA DE CATEGORIZACIÓN ---
        # Agrupamos por producto y sumamos comisiones
        mina_de_oro = df.groupby("Producto")["Comisión Recibida ($)"].sum().idxmax()
        ganancia_top = df.groupby("Producto")["Comisión Recibida ($)"].sum().max()
        # --------------------------------------

        print(f"\n{CYAN}╔═════════════════════════════════════════════════════╗{FIN}")
        print(
            f"{CYAN}║{FIN} {NEGRITA}🚀 DASHBOARD INTELIGENTE - MODO NEORVRY PRO{FIN}    {CYAN}║{FIN}"
        )
        print(f"{CYAN}╠═════════════════════════════════════════════════════╣{FIN}")

        print(
            f"{CYAN}║{FIN} {NEGRITA}💰 TOTAL ACUMULADO:{FIN}   {VERDE}${total_acumulado:,.2f}{FIN}"
        )
        print(
            f"{CYAN}║{FIN} {NEGRITA}🏆 MINA DE ORO:{FIN}       {AMARILLO}{mina_de_oro}{FIN}"
        )
        print(
            f"{CYAN}║{FIN} {NEGRITA}📈 GANANCIA NICHO:{FIN}    {VERDE}${ganancia_top:,.2f}{FIN}"
        )

        # Barra de progreso
        porcentaje = (total_acumulado / META_FINAL) * 100
        bloques = int(porcentaje * 2) if porcentaje < 10 else 2
        barra = "█" * bloques + "░" * (20 - bloques)
        print(
            f"{CYAN}║{FIN} {NEGRITA}📊 PROGRESO:{FIN}         [{barra}] {porcentaje:.4f}%"
        )

        print(f"{CYAN}╠═════════════════════════════════════════════════════╣{FIN}")
        print(
            f"{CYAN}║{FIN} {NEGRITA}🎯 META FINAL:{FIN}       {AZUL}$1,000,000.00{FIN}"
        )
        print(f"{CYAN}╚═════════════════════════════════════════════════════╝{FIN}\n")

    except Exception as e:
        print(f"\n{AMARILLO}[!] Error en el análisis: {e}{FIN}")


if __name__ == "__main__":
    ejecutar_reporte()
