import os

G, R, Y, C, W = "\033[92m", "\033[91m", "\033[93m", "\033[96m", "\033[0m"


def ver_leads():
    os.system("clear")
    print(f"{G}╔══════════════════════════════════════╗")
    print(f"║       🛡️ BÚNKER DE LEADS - R22        ║")
    print(f"╚══════════════════════════════════════╝{W}")
    print(f"{Y}>> EXTRACCIÓN DE DATOS SEGURA...{W}\n")

    if os.path.exists("leads_bunker.txt"):
        with open("leads_bunker.txt", "r") as f:
            leads = f.readlines()
            if not leads:
                print(f"{R}[!] Búnker vacío. Inicia el ataque en el CRM.{W}")
            else:
                print(f"{C}FECHA           | NOMBRE         | PRODUCTO{W}")
                print("-" * 50)
                for line in leads:
                    print(f"{G}{line.strip()}{W}")
                print("-" * 50)

                # Lógica de Inteligencia Financiera
                total = len(leads)
                dinero_potencial = total * 50  # Estimado de comisión promedio

                print(f"{Y}TOTAL DE LEADS: {total}{W}")
                print(f"{G}DINERO EN MESA ESTIMADO: ${dinero_potencial}.00 USD{W}")
                print(
                    f"{C}PROGRESO META $1M: {round((dinero_potencial/1000000)*100, 4)}%{W}"
                )
    else:
        print(f"{R}[!] No hay base de datos detectada.{W}")

    input(f"\n{W}Presiona Enter para volver...")


if __name__ == "__main__":
    ver_leads()
