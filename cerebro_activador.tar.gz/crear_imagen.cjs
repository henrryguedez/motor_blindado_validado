const { Jimp, loadFont } = require('jimp');
const fs = require('fs');
const path = require('path');

async function generarOfertaPersonalizada(nombre, nicho) {
    console.log(`🚀 NEOVRY HUB: Diseñando con contraste para ${nombre}...`);
    const rutaImagen = path.join(process.cwd(), 'assets', `${nicho}.jpg`);
    
    try {
        const image = await Jimp.read(fs.readFileSync(rutaImagen));
        console.log(`✅ Imagen cargada (${image.bitmap.width}x${image.bitmap.height}px)`);

        // 1. CARGAMOS FUENTE BLANCA (Para que resalte en fondos oscuros)
        const font = await loadFont("https://unpkg.com/@jimp/plugin-print/fonts/open-sans/open-sans-64-white/open-sans-64-white.fnt");

        const texto = `OFERTA ESPECIAL | PARA: ${nombre.toUpperCase()}`;

        // 2. CREAMOS UNA FRANJA BLANCA TRANSLÚCIDA PARA EL FONDO
        // Esto asegura que el texto sea legible, sea cual sea la imagen.
        const altoFranja = Math.floor(image.bitmap.height * 0.12);
        const franjaBlancaTranslucida = new Jimp({
            width: image.bitmap.width,
            height: altoFranja,
            color: 0xFFFFFFFF // Blanco con 50% de opacidad
        });

        // 3. PEGAR LA FRANJA TRANSLÚCIDA EN LA PARTE INFERIOR
        image.composite(franjaBlancaTranslucida, 0, image.bitmap.height - altoFranja, {
            mode: Jimp.BLEND_SOURCE_OVER,
            opacitySource: 0.5 // 50% transparente
        });

        // 4. ESCRIBIR EL TEXTO CENTRADO SOBRE LA FRANJA
        image.print({
            font: font,
            x: 0,
            y: image.bitmap.height - (altoFranja / 1.5),
            text: {
                text: texto,
                alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER
            },
            maxWidth: image.bitmap.width
        });

        const pathSalida = path.join(process.cwd(), 'assets', `oferta_${nombre}.jpg`);
        await image.write(pathSalida);
        console.log(`💾 ¡DISEÑO PERFECTO!: ${pathSalida}`);
        
        return pathSalida;
    } catch (err) {
        console.error("❌ ERROR EN EL MOTOR DE DISEÑO:", err.message);
        return undefined;
    }
}

module.exports = { generarOfertaPersonalizada };
