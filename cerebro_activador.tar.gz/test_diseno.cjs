const { generarOfertaPersonalizada } = require('./crear_imagen.cjs');

async function prueba() {
    console.log("🎨 Dibujando oferta para Katherine...");
    const resultado = await generarOfertaPersonalizada("Katherine", "reposteria");
    console.log("✅ ¡Imagen creada en!: " + resultado);
}

prueba();
